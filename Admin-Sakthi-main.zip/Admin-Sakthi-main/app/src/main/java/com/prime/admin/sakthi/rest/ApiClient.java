package com.prime.admin.sakthi.rest;

import android.util.Log;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    private static Retrofit retrofit;

    static {
        retrofit = null;
    }

    public ApiClient(String baseUrl) {
        initializeRetrofit(baseUrl);
    }

    public static ApiInterface getClient(String baseUrl) {
        return new ApiClient(baseUrl).getRetrofitInstance().create(ApiInterface.class);
    }

    public static ApiInterface getClientUpdate(String url, String baseUrl) {
        Log.d("checkstatusvaluee", url);

        String base_Url_Update;

        switch (url.toLowerCase()) {
            case "msrama":
            case "mrama":
                base_Url_Update = "https://mramachandran.in/";
                break;
            case "tes":
                base_Url_Update = "https://tes2015.com/";
                break;
            case "bsc":
                base_Url_Update = "https://bsc2019.com/";
                break;
            case "sest":
            case "theest":
                base_Url_Update = "https://sest.in/";
                break;
            case "mrbirla":
            case "jsrtrade":
                base_Url_Update = "http://jsrtrade.in/";
                break;
            case "bsakthi":
            default:
                base_Url_Update = baseUrl;
        }

        return getClient(base_Url_Update);
    }

    private void initializeRetrofit(String baseUrl) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .callTimeout(5, TimeUnit.MINUTES)
                .connectTimeout(5, TimeUnit.MINUTES)
                .readTimeout(5, TimeUnit.MINUTES)
                .writeTimeout(5, TimeUnit.MINUTES);

        OkHttpClient instance = builder.build();
        retrofit = new Retrofit.Builder().baseUrl(baseUrl).client(instance).addConverterFactory(GsonConverterFactory.create()).build();
    }

    public Retrofit getRetrofitInstance() {
        return retrofit;
    }

}
