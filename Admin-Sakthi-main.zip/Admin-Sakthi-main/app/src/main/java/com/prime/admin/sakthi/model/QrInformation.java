package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Admin on 11/24/2016.
 */

public class QrInformation {

    @SerializedName("sid")
    String sid;

    @SerializedName("status")
    String status;


    @SerializedName("date")
    String date;

    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public String getStatusm() {
        return status;
    }

    public void setStatusm(String status) {
        this.status = status;
    }

    public String getDates() {
        return date;
    }

    public void setDates(String date) {
        this.date = date;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public int getSuccess() {
        return this.success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
