package com.prime.admin.sakthi.activity.qrdirectdeliveredbillclose;

import static com.prime.admin.sakthi.util.Utils.makeNotification;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.gson.Gson;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;
import com.prime.admin.sakthi.activity.SQLiteQrDirectDeliveredScan.QrDirectDeliveredScan;
import com.prime.admin.sakthi.activity.SQLiteQrDirectDeliveredScan.QrDirectDeliveredScanDBHelper;
import com.prime.admin.sakthi.model.DriverBillCloseDetails;
import com.prime.admin.sakthi.model.DriverBillCloseInformationRespone;
import com.prime.admin.sakthi.model.QrDataInformation;
import com.prime.admin.sakthi.model.QrDataInformationRespone;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity QR";
    final int REQUEST_GALLERY = 9544;
    String Data1, Data2, Data3, Data4, Data5, class_check = "", qr_data = "", part_image;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    ProgressDialog progressDialog;
    TextView tv_balance_amount_val, tv_current_status_val, tv_bill_no_val, tv_selected_date_val, tv_selected_date, tv_changing_status_val, tv_heading, tv_yes, tv_no, tv_Seelected_Driver_val;
    Button btn_back_to_qr_scan, btn_submit_status;
    ImageView Image;
    CardView card_view;
    LinearLayout btn;
    SimpleDateFormat sdfs;

    String[] parts = new String[0];
    String baseUrl = "";
    private QrDirectDeliveredScanDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultdlsdbc);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        baseUrl = Utils.getBaseUrl(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        tv_balance_amount_val = findViewById(R.id.tv_balance_amount_val);
        tv_current_status_val = findViewById(R.id.tv_current_status_val);
        tv_selected_date_val = findViewById(R.id.tv_selected_date_val);
        tv_selected_date = findViewById(R.id.tv_selected_date);
        tv_changing_status_val = findViewById(R.id.tv_changing_status_val);
        tv_heading = findViewById(R.id.tv_heading);
        tv_bill_no_val = findViewById(R.id.tv_bill_no_val);
        sdfs = new SimpleDateFormat("yyyy-MM-dd");

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

            private void updateLabel() {
                String myFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                tv_selected_date_val.setText(sdf.format(myCalendar.getTime()));
                Common.DeliveredBillCLoseDate = sdf.format(myCalendar.getTime());
            }
        };

        if (Common.DeliveredBillCLoseDate == null) {

            sdfs = new SimpleDateFormat("yyyy-MM-dd");
            Common.DeliveredBillCLoseDate = sdfs.format(new Date());
            tv_selected_date_val.setText(Common.DeliveredBillCLoseDate);

        } else if (Common.DeliveredBillCLoseDate.isEmpty()) {

            sdfs = new SimpleDateFormat("yyyy-MM-dd");
            Common.DeliveredBillCLoseDate = sdfs.format(new Date());
            tv_selected_date_val.setText(Common.DeliveredBillCLoseDate);

        } else {
            tv_selected_date_val.setText("" + Common.DeliveredBillCLoseDate);
        }


        tv_selected_date_val.setOnClickListener(view -> new DatePickerDialog(MainActivity.this, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show());

        btn_back_to_qr_scan = findViewById(R.id.btn_back_to_qr_scan);
        btn_submit_status = findViewById(R.id.btn_submit_status);

        card_view = findViewById(R.id.card_view);
        Image = findViewById(R.id.Image);

        if (getIntent() != null) {
            class_check = getIntent().getStringExtra("qr");

            if (class_check.equalsIgnoreCase("1")) {
                qr_data = getIntent().getStringExtra("qr_data");
                parts = qr_data.split("-");
                qr_data = parts[0];
            }
        }

        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Scan For Driver Direct Delivered Bill Close"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        Log.d("checkrepsonsem", "" + qr_data);
        String baseUrl = Utils.getBaseUrl(this);
        ApiClient.getClientUpdate(parts[1], baseUrl).setQrDataInfo(qr_data).enqueue(new MainActivity.Receipt());

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "" + requestCode + "\t" + resultCode + "\t" + data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_GALLERY) {
                Uri dataimage = data.getData();
                String[] imageprojection = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(dataimage, imageprojection, null, null, null);

                if (cursor != null) {
                    cursor.moveToFirst();
                    int indexImage = cursor.getColumnIndex(imageprojection[0]);
                    part_image = cursor.getString(indexImage);

                    if (part_image != null) {
                        File image = new File(part_image);
                        Image.setImageBitmap(BitmapFactory.decodeFile(image.getAbsolutePath()));
                    }
                }
            }
        }
    }

    class Receipt implements Callback<QrDataInformationRespone> {

        Receipt() {

        }

        @Override
        public void onResponse(Call<QrDataInformationRespone> call, Response<QrDataInformationRespone> response) {
            if (response.isSuccessful()) {
                System.out.println("Entering");
                int success = response.body().getSuccess();
                String messsge = response.body().getMessage();
                System.out.println("Success" + success);
                Log.d("checkrepsonsem", "" + success + "\t" + response);
                if (success == 1) {

                    String message = response.body().getMessage();
                    Log.d("progressDialog", "" + message);

                    ArrayList<QrDataInformation> qritems = response.body().getResults();

                    Gson gson = new Gson();
                    String valuesString = gson.toJson(qritems);
                    System.out.println(valuesString);

                    Log.d("checkrepsonsem", "" + valuesString);

                    for (int i = 0; i < qritems.size(); i++) {

                        Data1 = qritems.get(i).getBalance_Amount();

                        Data2 = qritems.get(i).getDelivery_type();

                        Data3 = qritems.get(i).getDelivered_sign();

                        Data4 = qritems.get(i).getDriver_status();

                        Data5 = qritems.get(i).getBill_no();

                        Log.d("checkrepsonsem", "" + Data1);
                        Log.d("checkrepsonsem", "" + Data2);
                        Log.d("checkrepsonsem", "" + Data3);
                        Log.d("checkrepsonsem", "" + Data4);

                        if (Data1 == null && Data3 == null && Data4 == null) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            btn_submit_status.setVisibility(View.GONE);
                            card_view.setVisibility(View.GONE);
                            btn.setVisibility(View.GONE);

                            Image.setImageResource(R.drawable.closebutton);

                            btn_back_to_qr_scan.setOnClickListener(view -> {

                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                MainActivity.this.finish();

                            });

                        } else if (Data1.isEmpty() && Data3.isEmpty() && Data4.isEmpty()) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            btn_submit_status.setVisibility(View.GONE);
                            card_view.setVisibility(View.GONE);
                            btn.setVisibility(View.GONE);

                            Image.setImageResource(R.drawable.closebutton);

                            btn_back_to_qr_scan.setOnClickListener(view -> {

                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                MainActivity.this.finish();

                            });

                        } else if (Data2.equals("direct delivery")) {

                            if (!Data3.equals("cancel")) {

                                if (Data3.equals("delivered")) {

                                    if (Data4.equals("incompany")) {

                                        progressDialog.setCancelable(false);
                                        progressDialog.dismiss();

                                        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                                .setTitleText("Bill Already Scanned")
                                                .setConfirmText("Ok")
                                                .setConfirmClickListener(sDialog -> {
                                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                                    MainActivity.this.finish();
                                                    sDialog.cancel();
                                                })
                                                .show();

                                    } else if (Data4.equals("indriver")) {

                                        progressDialog.setCancelable(false);
                                        progressDialog.dismiss();

                                        tv_heading.setText("Direct Delivered Bill Close");
                                        tv_balance_amount_val.setText("" + Data1);
                                        tv_selected_date_val.setText("" + Common.DeliveredBillCLoseDate);
                                        tv_current_status_val.setText("InDriver");
                                        tv_changing_status_val.setText("InCompany");
                                        tv_bill_no_val.setText("" + Data5);

                                        btn_submit_status.setVisibility(View.GONE);

                                        btn_back_to_qr_scan.setOnClickListener(view -> {

                                            startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                            MainActivity.this.finish();

                                        });

                                        if (Common.ImageForDirectDeliveredScanOrg == null) {
                                            Image.setImageResource(R.drawable.addimage);
                                        } else if (Common.ImageForDirectDeliveredScanOrg.isEmpty()) {
                                            Image.setImageResource(R.drawable.addimage);
                                        } else {
                                            Image.setImageDrawable(Drawable.createFromPath(Common.ImageForDirectDeliveredScanOrg));

                                            btn_submit_status.setVisibility(View.VISIBLE);

                                            btn_submit_status.setOnClickListener(view -> {

                                                progressDialog.setCancelable(false);
                                                progressDialog.dismiss();

                                                String status_s = "InCompany";

                                                progressDialog = new ProgressDialog(MainActivity.this);
                                                progressDialog.setMessage("Loading..."); // Setting Message
                                                progressDialog.setTitle("Status Submit"); // Setting Title
                                                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                                progressDialog.show(); // Display Progress Dialog


                                                Log.d("InCompany", "" + Common.QrData);
                                                Log.d("InCompany", "" + status_s);

                                                dbHelper = new QrDirectDeliveredScanDBHelper(MainActivity.this);

                                                QrDirectDeliveredScan person = new QrDirectDeliveredScan(Common.QrData, Common.DeliveredBillCLoseDate, Common.ImageForDirectDeliveredScanOrg);
                                                dbHelper.saveNewPerson(person);

                                                makeNotification(0, "" + Common.QrData + " - " + status_s, MainActivity.this, "Qr Code Status Generated", com.prime.admin.sakthi.activity.MainActivity.class);
                                                // Add as notification
//                                                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//                                                manager.notify(0, builder.build());

//                                                ((ApiInterface) ApiClient.getClient().create(ApiInterface.class)).setDeliveredBillClose(partImage, filename, filename1, filename2, filename3).enqueue(new MainActivity.QrDrReceipt());
                                                ApiClient.getClient(baseUrl).setQrDirectDeliveredScanData(Common.QrData, status_s).enqueue(new QrDrReceipt());


                                            });
                                        }

                                    }
                                } else if (Data3.equals("sent to delivery")) {

                                    progressDialog.setCancelable(false);
                                    progressDialog.dismiss();

                                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                            .setTitleText("Return Bill")
                                            .setConfirmText("Ok")
                                            .setConfirmClickListener(sDialog -> {
                                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                                MainActivity.this.finish();
                                                sDialog.cancel();
                                            })
                                            .show();

                                }

                            } else {
                                progressDialog.setCancelable(false);
                                progressDialog.dismiss();

                                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                        .setTitleText("Cancelled Bill")
                                        .setConfirmText("Ok")
                                        .setConfirmClickListener(sDialog -> {
                                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                            MainActivity.this.finish();
                                            sDialog.cancel();
                                        })
                                        .show();
                            }
                        } else {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                    .setTitleText("Lorry Shed Bill")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(sDialog -> {
                                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                        MainActivity.this.finish();
                                        sDialog.cancel();
                                    })
                                    .show();
                        }
                    }

                } else if (success == 0) {
                    String message = response.body().getMessage();
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();
                } else {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();
                }
            }
        }

        @Override
        public void onFailure(Call<QrDataInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class QrDrReceipt implements Callback<DriverBillCloseInformationRespone> {

        QrDrReceipt() {

        }

        @Override
        public void onResponse(Call<DriverBillCloseInformationRespone> call, Response<DriverBillCloseInformationRespone> response) {
            if (response.isSuccessful()) {
                System.out.println("Entering");
                int success = response.body().getSuccess();
                String messsge = response.body().getMessage();
                System.out.println("Success" + success);
                Log.d("checkrepsonses", "" + success + "\t" + response);
                if (success == 1) {
                    String message = response.body().getMessage();
                    Log.d("progressDialog", "" + message);
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    Toast.makeText(MainActivity.this, "Status Submitted",
                            Toast.LENGTH_LONG).show();

                    Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                    i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i1);

                } else if (success == 0) {
                    String message = response.body().getMessage();
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setContentText("The Bill Status Already In : 'InCompany'")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();

                } else {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();

                }
            }
        }

        @Override
        public void onFailure(Call<DriverBillCloseInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class Qr implements Callback<DriverBillCloseDetails> {

        Qr() {

        }

        @Override
        public void onResponse(Call<DriverBillCloseDetails> call, Response<DriverBillCloseDetails> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonse", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(MainActivity.this, "Status Submitted",
                        Toast.LENGTH_LONG).show();

                Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);


            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InDriver'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        })
                        .show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InDriver'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        })
                        .show();


            }
        }

        @Override
        public void onFailure(Call<DriverBillCloseDetails> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }
}
