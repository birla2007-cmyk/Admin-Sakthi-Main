package com.prime.admin.sakthi.activity.qrcompanyscanwithoutimg;

import static com.prime.admin.sakthi.util.Utils.makeNotification;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.gson.Gson;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;
import com.prime.admin.sakthi.model.OrResponseApiModel;
import com.prime.admin.sakthi.model.QrDataInformation;
import com.prime.admin.sakthi.model.QrDataInformationRespone;
import com.prime.admin.sakthi.model.QrInformation;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity QR";
    final int REQUEST_GALLERY = 9544;
    String class_check = "", qr_data = "", part_image;
    ProgressDialog progressDialog;
    String DataQr, Data1, Data2, Data3, Data4, Datadt, Data5;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    TextView tv_balance_amount_val, tv_current_status_val, tv_bill_no_val, tv_selected_date_val, tv_changing_status_val, tv_selected_date, tv_heading;
    Button btn_back_to_qr_scan, btn_submit_status;
    ImageView Image;
    CardView card_view;

    SimpleDateFormat sdfs;
    String[] parts = new String[0];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_swoi);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);

        tv_balance_amount_val = findViewById(R.id.tv_balance_amount_val);
        tv_current_status_val = findViewById(R.id.tv_current_status_val);
        tv_selected_date_val = findViewById(R.id.tv_selected_date_val);
        tv_selected_date = findViewById(R.id.tv_selected_date);
        tv_changing_status_val = findViewById(R.id.tv_changing_status_val);
        tv_heading = findViewById(R.id.tv_heading);
        tv_bill_no_val = findViewById(R.id.tv_bill_no_val);
        btn_back_to_qr_scan = findViewById(R.id.btn_back_to_qr_scan);
        btn_submit_status = findViewById(R.id.btn_submit_status);

        card_view = findViewById(R.id.card_view);

        sdfs = new SimpleDateFormat("yyyy-MM-dd");

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

            private void updateLabel() {
                String myFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                tv_selected_date_val.setText(sdf.format(myCalendar.getTime()));
                Common.DateForCompanyWithhoutImg = sdf.format(myCalendar.getTime());
            }
        };

        if (getIntent() != null) {
            class_check = getIntent().getStringExtra("qr");

            if (class_check.equalsIgnoreCase("1")) {
                qr_data = getIntent().getStringExtra("qr_data");
                parts = qr_data.split("-");
                DataQr = parts[0];
                qr_data = DataQr;
            }
        }

        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Scan For Company"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        String baseUrl = Utils.getBaseUrl(this);
        ApiClient.getClientUpdate(parts[1], baseUrl).setQrDataInfo(qr_data).enqueue(new MainActivity.Receipt());

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "" + requestCode + "\t" + resultCode + "\t" + data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_GALLERY) {
                Uri dataimage = data.getData();
                String[] imageprojection = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(dataimage, imageprojection, null, null, null);

                if (cursor != null) {
                    cursor.moveToFirst();
                    int indexImage = cursor.getColumnIndex(imageprojection[0]);
                    part_image = cursor.getString(indexImage);

                    if (part_image != null) {
                        File image = new File(part_image);
                        Image.setImageBitmap(BitmapFactory.decodeFile(image.getAbsolutePath()));
                    }
                }
            }
        }
    }

    class Receipt implements Callback<QrDataInformationRespone> {

        Receipt() {

        }

        @Override
        public void onResponse(Call<QrDataInformationRespone> call, Response<QrDataInformationRespone> response) {
            if (response.isSuccessful()) {
                System.out.println("Entering");
                int success = response.body().getSuccess();
                String messsge = response.body().getMessage();
                System.out.println("Success" + success);
                Log.d("checkrepsonsem", "" + success + "\t" + response);
                if (success == 1) {

                    String message = response.body().getMessage();
                    Log.d("progressDialog", "" + message);

                    ArrayList<QrDataInformation> qritems = response.body().getResults();

                    Gson gson = new Gson();
                    String valuesString = gson.toJson(qritems);
                    System.out.println(valuesString);

                    Log.d("checkrepsonsem", "" + valuesString);

                    for (int i = 0; i < qritems.size(); i++) {

                        Data1 = qritems.get(i).getBalance_Amount();
                        Data2 = qritems.get(i).getStatusm();
                        Data3 = qritems.get(i).getDelivered_sign();
                        Data4 = qritems.get(i).getLorrshed_status();
                        Data5 = qritems.get(i).getBill_no();

                        Log.d("checkrepsonsem", "" + Data1);

                        Log.d("checkrepsonsem", "" + Data2);

                        Datadt = sdfs.format(new Date());

                        String Stst = "incompany";
                        String Ststsf = "finish";

                        if (Data1 == null) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Warning !..").setContentText("No Record Found").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                }
                            }).show();

                        }
                        if (Data2 == null) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Warning !..").setContentText("No Record Found").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                }
                            }).show();

                        }
                        if (Data2.equals(Ststsf)) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Warning !..").setContentText("No Record Found:  The Bill Is Finished").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                }
                            }).show();

                        } else if (Data2.equals(Stst)) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Warning !..").setContentText("The Bill Status Already In : 'InCompany'").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                }
                            }).show();

                        } else if (Data3.equals("delivered")) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();
                            tv_heading.setText("Scan For Company");
                            tv_balance_amount_val.setText("" + Data1);
                            tv_current_status_val.setText("" + Data2);
                            tv_changing_status_val.setText("InCompany");
                            tv_selected_date_val.setText("" + Common.DateForCompanyWithhoutImg);
                            tv_bill_no_val.setText("" + Data5);

                            btn_submit_status.setVisibility(View.VISIBLE);

                            tv_selected_date_val.setOnClickListener(view -> new DatePickerDialog(MainActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show());

                            btn_back_to_qr_scan.setOnClickListener(view -> {
                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                MainActivity.this.finish();
                            });

                            btn_submit_status.setOnClickListener(view -> {

                                progressDialog = new ProgressDialog(MainActivity.this);
                                progressDialog.setMessage("Loading..."); // Setting Message
                                progressDialog.setTitle("Status"); // Setting Title
                                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                progressDialog.show(); // Display Progress Dialog
                                String Status = "InCompany";
                                Log.d("M", "" + DataQr);
                                Log.d("Ma", "" + Status);
                                Log.d("Man", "" + Common.DateForCompanyWithhoutImg);

                                makeNotification(0, "" + DataQr + " - " + Status, MainActivity.this, "Qr Code Status Generated", MainActivity.class);

//                                NotificationCompat.Builder builder =
//                                        new NotificationCompat.Builder(MainActivity.this)
//                                                .setSmallIcon(R.drawable.primesaleslogo)
//                                                .setContentTitle("Qr Code Status Generated")
//                                                .setContentText("" + DataQr + " - " + Status);
//
//                                Intent notificationIntent = new Intent(MainActivity.this, com.prime.admin.estimate.activity.MainActivity.class);
//                                PendingIntent contentIntent = PendingIntent.getActivity(MainActivity.this, 0, notificationIntent,
//                                        PendingIntent.FLAG_UPDATE_CURRENT);
//                                builder.setContentIntent(contentIntent);
//
//                                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//                                manager.notify(0, builder.build());

                                String baseUrl = Utils.getBaseUrl(MainActivity.this);
                                ApiClient.getClientUpdate(parts[1], baseUrl).setUserQRWithoutImgCOmpanyInfo(DataQr, Status, Common.DateForCompanyWithhoutImg).enqueue(new QrScanReceipt());

                            });

                        } else if (Data4.equals("delivered")) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();
                            tv_heading.setText("Scan For Company");
                            tv_balance_amount_val.setText("" + Data1);
                            tv_current_status_val.setText("" + Data2);
                            tv_changing_status_val.setText("InCompany");
                            tv_selected_date_val.setText("" + Common.DateForCompanyWithhoutImg);
                            tv_bill_no_val.setText("" + Data5);

                            btn_submit_status.setVisibility(View.VISIBLE);

                            tv_selected_date_val.setOnClickListener(view -> new DatePickerDialog(MainActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show());

                            btn_back_to_qr_scan.setOnClickListener(view -> {
                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                MainActivity.this.finish();
                            });

                            btn_submit_status.setOnClickListener(view -> {

                                progressDialog = new ProgressDialog(MainActivity.this);
                                progressDialog.setMessage("Loading..."); // Setting Message
                                progressDialog.setTitle("Status"); // Setting Title
                                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                progressDialog.show(); // Display Progress Dialog
                                String Status = "InCompany";
                                Log.d("M", "" + DataQr);
                                Log.d("Ma", "" + Status);
                                Log.d("Man", "" + Common.DateForCompanyWithhoutImg);
                                makeNotification(0, "" + DataQr + " - " + Status, MainActivity.this, "Qr Code Status Generated", MainActivity.class);

//                                NotificationCompat.Builder builder =
//                                        new NotificationCompat.Builder(MainActivity.this)
//                                                .setSmallIcon(R.drawable.primesaleslogo)
//                                                .setContentTitle("Qr Code Status Generated")
//                                                .setContentText("" + DataQr + " - " + Status);
//
//                                Intent notificationIntent = new Intent(MainActivity.this, com.prime.admin.estimate.activity.MainActivity.class);
//                                PendingIntent contentIntent = PendingIntent.getActivity(MainActivity.this, 0, notificationIntent,
//                                        PendingIntent.FLAG_UPDATE_CURRENT);
//                                builder.setContentIntent(contentIntent);
//
//                                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//                                manager.notify(0, builder.build());

                                String baseUrl = Utils.getBaseUrl(MainActivity.this);
                                ApiClient.getClientUpdate(parts[1], baseUrl).setUserQRWithoutImgCOmpanyInfo(DataQr, Status, Common.DateForCompanyWithhoutImg).enqueue(new QrScanReceipt());

                            });

                        } else {
                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Warning !..").setContentText("No Record Found:  Undelivered Bill").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                }
                            }).show();
                        }

                    }
                } else if (success == 0) {
                    String message = response.body().getMessage();
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("No Record Found").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        }
                    }).show();
                } else {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("No Record Found").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        }
                    }).show();
                }
            }
        }

        @Override
        public void onFailure(Call<QrDataInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class Qr implements Callback<QrInformation> {

        Qr() {

        }

        @Override
        public void onResponse(Call<QrInformation> call, Response<QrInformation> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonse", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(MainActivity.this, "Status Submitted", Toast.LENGTH_LONG).show();

                Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);

            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("No Record Found").setContentText("The Bill Status Already In : 'InSalesman'").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                        MainActivity.this.finish();
                        sDialog.cancel();
                    }
                }).show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("No Record Found").setContentText("The Bill Status Already In : 'InSalesman'").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                        MainActivity.this.finish();
                        sDialog.cancel();
                    }
                }).show();
            }
        }

        @Override
        public void onFailure(Call<QrInformation> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class QrScanReceipt implements Callback<OrResponseApiModel> {

        QrScanReceipt() {

        }

        @Override
        public void onResponse(Call<OrResponseApiModel> call, Response<OrResponseApiModel> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonse", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(MainActivity.this, "Status Submitted", Toast.LENGTH_LONG).show();

                Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);

            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("No Record Found").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                        MainActivity.this.finish();
                        sDialog.cancel();
                    }
                }).show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("No Record Found").setConfirmText("Ok").setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                        MainActivity.this.finish();
                        sDialog.cancel();
                    }
                }).show();
            }
        }

        @Override
        public void onFailure(Call<OrResponseApiModel> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

}
