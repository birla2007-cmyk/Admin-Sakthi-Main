package com.prime.admin.sakthi.activity.sai;

interface RPResultListener {
    void onPermissionGranted();

    void onPermissionDenied();
}
