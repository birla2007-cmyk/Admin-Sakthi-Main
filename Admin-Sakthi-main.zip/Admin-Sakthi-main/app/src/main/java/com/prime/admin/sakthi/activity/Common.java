package com.prime.admin.sakthi.activity;

public class Common {

    public static String DateForSalesman = "";
    public static String DateForCompany = "";
    public static String DateForCompanyWithhoutImg = "";
    public static String DateForDriverBillTaken = "";
    public static String DriverNameForBllTaken = "";
    public static String DriverIDForBllTaken = "";

    public static String LoginCache = "";
    public static String LoginCacheCheck = "";

    public static String QrCompanyListDataCheck = "";
    public static long Data1 = 0;

    public static String ImageForCompanyScan = "";
    public static String ImageForCompanyScanOrg = "";
    public static boolean ImageForCompanyScanII = Boolean.parseBoolean("");
    public static boolean ImageForCompanyScanIIOrg = Boolean.parseBoolean("");
    public static String ImageForCompanyScanQr = "";
    public static String ImageForDirectDeliveredScan = "";
    public static String ImageForDirectDeliveredScanOrg = "";
    public static boolean ImageForDirectDeliveredScanII = Boolean.parseBoolean("");
    public static boolean ImageForDirectDeliveredScanIIOrg = Boolean.parseBoolean("");
    public static String ImageForLSDeliveredScan = "";
    public static String ImageForLSDeliveredScanOrg = "";
    public static boolean ImageForLSDeliveredScanII = Boolean.parseBoolean("");
    public static boolean ImageForLSDeliveredScanIIOrg = Boolean.parseBoolean("");

    public static String LSDBC = "";
    public static String QrData = "";
    public static String DeliveredBillCLoseDate = "";
    public static String PhoneIMEI = "";

    public static String GetLangitude = "";
    public static String GetLatitude = "";
    public static String GetAddress = "";

}
