package com.prime.admin.sakthi.adapter;

import android.widget.Filter;

import com.prime.admin.sakthi.model.DriverInfoDetails;

import java.util.ArrayList;

public class DialogDriverCustomFilter extends Filter {
    DialogDriverListAdapter dialogItemListAdapter;
    ArrayList<DriverInfoDetails> filterLista;

    public DialogDriverCustomFilter(ArrayList<DriverInfoDetails> filterLista, DialogDriverListAdapter dialogItemListAdapter) {
        this.dialogItemListAdapter = dialogItemListAdapter;
        this.filterLista = filterLista;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();
        if (constraint != null && constraint.length() > 0) {
            constraint = constraint.toString().toLowerCase();
            ArrayList<DriverInfoDetails> filteredList = new ArrayList<>();
            for (int i = 0; i < filterLista.size(); i++) {
                if (filterLista.get(i).getDriver_name().toLowerCase().contains(constraint)) {
                    filteredList.add(filterLista.get(i));
                }
            }
            results.count = filteredList.size();
            results.values = filteredList;
        } else {
            results.count = filterLista.size();
            results.values = filterLista;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        dialogItemListAdapter.itemlist = (ArrayList<DriverInfoDetails>) results.values;
        dialogItemListAdapter.notifyDataSetChanged();
    }
}
