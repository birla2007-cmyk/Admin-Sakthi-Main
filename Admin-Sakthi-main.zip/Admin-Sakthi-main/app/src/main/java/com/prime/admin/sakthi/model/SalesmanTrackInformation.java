package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Admin on 11/24/2016.
 */

public class SalesmanTrackInformation {

    @SerializedName("longitude_number")
    String longitude_number;

    public String getLongitude_number() {
        return longitude_number;
    }

    public void setLongitude_number(String longitude_number) {
        this.longitude_number = longitude_number;
    }

}
