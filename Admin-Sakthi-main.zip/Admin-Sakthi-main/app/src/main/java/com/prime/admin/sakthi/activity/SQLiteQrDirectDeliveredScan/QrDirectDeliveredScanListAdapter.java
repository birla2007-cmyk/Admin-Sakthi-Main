package com.prime.admin.sakthi.activity.SQLiteQrDirectDeliveredScan;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.prime.admin.sakthi.R;

import java.util.List;

public class QrDirectDeliveredScanListAdapter extends RecyclerView.Adapter<QrDirectDeliveredScanListAdapter.ViewHolder> {
    private final List<QrDirectDeliveredScan> mPeopleList;
    private final Context mContext;
    private final RecyclerView mRecyclerV;


    // Provide a suitable constructor (depends on the kind of dataset)
    public QrDirectDeliveredScanListAdapter(List<QrDirectDeliveredScan> myDataset, Context context, RecyclerView recyclerView) {
        mPeopleList = myDataset;
        mContext = context;
        mRecyclerV = recyclerView;
    }

    public void add(int position, QrDirectDeliveredScan person) {
        mPeopleList.add(position, person);
        notifyItemInserted(position);
    }

    public void remove(int position) {
        mPeopleList.remove(position);
        notifyItemRemoved(position);
    }

    // Create new views (invoked by the layout manager)
    @Override
    public QrDirectDeliveredScanListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                                          int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(
                parent.getContext());
        View v =
                inflater.inflate(R.layout.single_row, parent, false);
        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        final QrDirectDeliveredScan person = mPeopleList.get(position);
        holder.soidTxtV.setText("SO-ID: " + person.getQr_data());
        holder.scandateTxtV.setText("Scan Date: " + person.getQr_scan_date());
        holder.imagepathTxtV.setText("Image Path: " + person.getQr_image_path());
        holder.ImageImgV.setImageDrawable(Drawable.createFromPath(person.getQr_image_path()));
//        Picasso.with(mContext).load(person.getImage()).placeholder(R.mipmap.ic_launcher).into(holder.personImageImgV);

        //listen to single view layout click
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setTitle("Choose option");
                builder.setMessage("Delete Data?");
                builder.setNeutralButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        QrDirectDeliveredScanDBHelper dbHelper = new QrDirectDeliveredScanDBHelper(mContext);
                        dbHelper.deletePersonRecord(person.getQr_company_id(), mContext);

                        mPeopleList.remove(position);
                        mRecyclerV.removeViewAt(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, mPeopleList.size());
                        notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.create().show();
            }
        });


    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mPeopleList.size();
    }

//    private void goToUpdateActivity(long personId){
//        Intent goToUpdate = new Intent(mContext, UpdateRecordActivity.class);
//        goToUpdate.putExtra("USER_ID", personId);
//        mContext.startActivity(goToUpdate);
//    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView soidTxtV;
        public TextView scandateTxtV;
        public TextView imagepathTxtV;
        public ImageView ImageImgV;


        public View layout;

        public ViewHolder(View v) {
            super(v);
            layout = v;
            soidTxtV = (TextView) v.findViewById(R.id.soid);
            scandateTxtV = (TextView) v.findViewById(R.id.scan_date);
            imagepathTxtV = (TextView) v.findViewById(R.id.image_path);
            ImageImgV = (ImageView) v.findViewById(R.id.image);
        }
    }


}