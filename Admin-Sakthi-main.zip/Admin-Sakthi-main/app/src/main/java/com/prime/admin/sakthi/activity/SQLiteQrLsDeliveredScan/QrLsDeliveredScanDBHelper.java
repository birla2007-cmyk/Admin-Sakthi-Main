package com.prime.admin.sakthi.activity.SQLiteQrLsDeliveredScan;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Ronsoft on 9/16/2017.
 */

public class QrLsDeliveredScanDBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "QrLsDeliveredScan.db";
    public static final String TABLE_NAME = "qr_company";
    public static final String COLUMN_QR_COMPANY_ID = "qr_company_id";
    public static final String COLUMN_QR_DATA = "qr_data";
    public static final String COLUMN_QR_SCAN_DATE = "qr_scan_date";
    public static final String COLUMN_QR_IMAGE_PATH = "qr_image_path";
    private static final int DATABASE_VERSION = 3;

    public QrLsDeliveredScanDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(" CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_QR_COMPANY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_QR_DATA + " TEXT NOT NULL, " +
                COLUMN_QR_SCAN_DATE + " TEXT NOT NULL, " +
                COLUMN_QR_IMAGE_PATH + " TEXT NOT NULL);"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // you can implement here migration process
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        this.onCreate(db);
    }

    public int countTable() {
        int countTable = 0;

        String query = "SELECT COUNT(*) FROM " + TABLE_NAME;

        Cursor cursor = getReadableDatabase().rawQuery(query, null);

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            countTable = cursor.getInt(0);
        }

        cursor.close();

        return countTable;
    }

    /**
     * create record
     **/
    public void saveNewPerson(QrLsDeliveredScan person) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QR_DATA, person.getQr_data());
        values.put(COLUMN_QR_SCAN_DATE, person.getQr_scan_date());
        values.put(COLUMN_QR_IMAGE_PATH, person.getQr_image_path());

        // insert
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public List<QrLsDeliveredScan> getAllQrLsDeliveredData() {
        List<QrLsDeliveredScan> locationLists = new ArrayList<>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {

                QrLsDeliveredScan QrLsDeliveredScan = new QrLsDeliveredScan(cursor.getLong(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3));
                // Adding contact to list
                locationLists.add(QrLsDeliveredScan);
            } while (cursor.moveToNext());
        }
        return locationLists;
    }

    /**
     * Query records, give options to filter results
     **/
    public List<QrLsDeliveredScan> peopleList(String filter) {
        String query;
        if (filter.equals("")) {
            //regular query
            query = "SELECT  * FROM " + TABLE_NAME;
        } else {
            //filter results by filter option provided
            query = "SELECT  * FROM " + TABLE_NAME + " ORDER BY " + filter;
        }

        List<QrLsDeliveredScan> personLinkedList = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        QrLsDeliveredScan person;

        if (cursor.moveToFirst()) {
            do {
                person = new QrLsDeliveredScan();

                person.setQr_company_id(cursor.getLong(cursor.getColumnIndex(COLUMN_QR_COMPANY_ID)));
                person.setQr_data(cursor.getString(cursor.getColumnIndex(COLUMN_QR_DATA)));
                person.setQr_scan_date(cursor.getString(cursor.getColumnIndex(COLUMN_QR_SCAN_DATE)));
                person.setQr_image_path(cursor.getString(cursor.getColumnIndex(COLUMN_QR_IMAGE_PATH)));

                personLinkedList.add(person);
            } while (cursor.moveToNext());
        }
        return personLinkedList;
    }

    /**
     * Query only 1 record
     **/
    public QrLsDeliveredScan getPerson(long qr_company_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT  * FROM " + TABLE_NAME + " WHERE qr_company_id=" + qr_company_id;
        Cursor cursor = db.rawQuery(query, null);

        QrLsDeliveredScan receivedPerson = new QrLsDeliveredScan();
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();

            receivedPerson.setQr_data(cursor.getString(cursor.getColumnIndex(COLUMN_QR_DATA)));
            receivedPerson.setQr_scan_date(cursor.getString(cursor.getColumnIndex(COLUMN_QR_SCAN_DATE)));
            receivedPerson.setQr_image_path(cursor.getString(cursor.getColumnIndex(COLUMN_QR_IMAGE_PATH)));
        }
        return receivedPerson;
    }

    /**
     * delete record
     **/
    public void deletePersonRecord(long qr_company_id, Context context) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("DELETE FROM " + TABLE_NAME + " WHERE qr_company_id='" + qr_company_id + "'");
        Toast.makeText(context, "Deleted successfully.", Toast.LENGTH_SHORT).show();

    }

    /**
     * update record
     **/
    public void updatePersonRecord(long qr_company_id, Context context, QrLsDeliveredScan updatedperson) {
        SQLiteDatabase db = this.getWritableDatabase();
        //you can use the constants above instead of typing the column names
        db.execSQL("UPDATE  " + TABLE_NAME + " SET qr_data ='" + updatedperson.getQr_data() + "', qr_scan_date ='" + updatedperson.getQr_scan_date() + "', qr_image_path ='" + updatedperson.getQr_image_path() + "'  WHERE qr_company_id='" + qr_company_id + "'");
        Toast.makeText(context, "Updated successfully.", Toast.LENGTH_SHORT).show();
    }

}
