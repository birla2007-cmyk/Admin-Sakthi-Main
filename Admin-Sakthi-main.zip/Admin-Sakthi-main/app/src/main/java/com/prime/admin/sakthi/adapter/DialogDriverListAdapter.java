package com.prime.admin.sakthi.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.model.DriverInfoDetails;

import java.util.ArrayList;

public class DialogDriverListAdapter extends RecyclerView.Adapter<DialogDriverListAdapter.ViewHolder> {
    public ArrayList<DriverInfoDetails> itemlist;
    public ArrayList<DriverInfoDetails> filterLista;
    CardView card;
    DialogDriverCustomFilter filtera;
    private final Context mContext;

    public DialogDriverListAdapter(Context mContext, ArrayList<DriverInfoDetails> itemlist) {
        this.mContext = mContext;
        this.itemlist = itemlist;
        this.filterLista = itemlist;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_card_item_list, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DialogDriverListAdapter.ViewHolder viewHolder, final int i) {
        viewHolder.tv_name.setText(itemlist.get(i).getDriver_name());
    }

//    @Override
//    public int getItemCount() {
//        return 0;
//    }

    @Override
    public int getItemCount() {
        System.out.println("mm" + itemlist.size());
        return itemlist.size();
    }

    public DialogDriverCustomFilter getFilter() {
        if (filtera == null) {
            filtera = new DialogDriverCustomFilter(filterLista, this);
        }
        return filtera;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final TextView tv_name;

        public ViewHolder(View view) {
            super(view);
            tv_name = (TextView) view.findViewById(R.id.tv_name);
            card = (CardView) view.findViewById(R.id.card_item_list);
            card.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            if (view.getId() == R.id.card_item_list) {
                if (position == 0) {

                }
            }
        }
    }
}