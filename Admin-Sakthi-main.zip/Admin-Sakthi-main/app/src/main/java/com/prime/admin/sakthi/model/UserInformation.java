package com.prime.admin.sakthi.model;

/**
 * Created by Admin on 11/16/2016.
 */

import com.google.gson.annotations.SerializedName;

import java.math.BigInteger;


public class UserInformation {

    @SerializedName("user_id")
    int userID;
    @SerializedName("user_name")
    String userName;
    @SerializedName("user_type")
    String userType;
    @SerializedName("user_email")
    String userEmail;
    @SerializedName("user_phone")
    BigInteger user_phone;
    @SerializedName("user_phone_option")
    BigInteger user_phone_option;
    @SerializedName("user_address")
    String user_address;
    @SerializedName("user_aadhra")
    BigInteger user_aadhra;
    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public int getSuccess() {

        return this.success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {

        this.message = message;
    }

    public int getUserID() {
        return this.userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return this.userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserType() {
        return this.userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public BigInteger getUserPhone() {
        return this.user_phone;
    }

    public void setUserPhone(BigInteger user_phone) {
        this.user_phone = user_phone;
    }

    public BigInteger getUserPhoneOpt() {
        return this.user_phone_option;
    }

    public void setUserPhoneOpt(BigInteger user_phone_option) {
        this.user_phone_option = user_phone_option;
    }

    public BigInteger getUserAadhar() {
        return this.user_aadhra;
    }

    public void setUserAadhar(BigInteger user_aadhra) {
        this.user_aadhra = user_aadhra;
    }

    public String getUserAddress() {
        return this.user_address;
    }

    public void setUserAddress(String user_address) {
        this.user_address = user_address;
    }

}