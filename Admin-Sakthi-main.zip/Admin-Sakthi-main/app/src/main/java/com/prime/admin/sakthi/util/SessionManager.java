package com.prime.admin.sakthi.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import java.util.HashMap;

public class SessionManager {
    public static final String KEY_NAME = "name";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_ITEM = "item";
    public static final String KEY_COUNT = "count";
    public static final String KEY_CUSTOMER = "customers";
    public static final String KEY_SALES = "sales";
    public static final String KEY_ID = "id";
    private static final String IS_LOGIN = "IsLoggedIn";
    private static final String KEY_TYPE = "type";
    static final String PREF_NAME = "Krishnapref";
    static final String baseUrl = "baseUrl";

    static Context _context;
    static Editor editor;
    static SharedPreferences pref;
    int PRIVATE_MODE;

    public SessionManager(Context context) {
        this.PRIVATE_MODE = 0;
        _context = context;
        pref = _context.getSharedPreferences(PREF_NAME, this.PRIVATE_MODE);
        editor = pref.edit();
    }

    public HashMap<String, String> getItems() {
        HashMap<String, String> user = new HashMap<String, String>();
        user.put(KEY_ITEM, pref.getString(KEY_ITEM, ""));
        return user;
    }

    public HashMap<String, String> getCompanyList() {
        HashMap<String, String> user = new HashMap<String, String>();
        user.put(KEY_CUSTOMER, pref.getString(KEY_CUSTOMER, ""));
        return user;
    }

    public void setCompanyList(String companyList) {
        editor.putString(KEY_CUSTOMER, companyList);
        editor.commit();
    }

    public void setSelectedItem(String selectedItem) {
        editor.putString("selecteditem", selectedItem);
        editor.commit();
    }

    public String getSelectedCompany() {
        String company = pref.getString("selectedcompany", "");
        return company;
    }

    public void setSelectedCompany(String selectedCompany) {
        editor.putString("selectedcompany", selectedCompany);
        editor.commit();
    }

    public void setCount(String count) {
        editor.putString(KEY_COUNT, count);
        editor.commit();
    }
}
