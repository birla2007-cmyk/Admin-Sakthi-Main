package com.prime.admin.sakthi.activity.sai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;

public class SplashScreen extends Activity implements Animation.AnimationListener {

    final static private String PREF_KEY_SHORTCUT_ADDED = "PREF_KEY_SHORTCUT_ADDED";
    private final boolean launched = false;
    Animation animFadein, animBounceH, animBounceP, animBouncePMS;

    private static void setFullScreen(Activity activity) {
        // Call before calling setContentView();
        activity.getWindow()
                .setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    //    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        setFullScreen(this);

        Common.LoginCache = "AdminApp";

        ImageView iv = findViewById(R.id.imgLogo);
        animFadein = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.fade_in);
        animFadein.setAnimationListener(SplashScreen.this);
        iv.setVisibility(View.VISIBLE);
        iv.startAnimation(animFadein);

        String fontPath = "BankGothic Bold.ttf";
        TextView aboutus = findViewById(R.id.textView2);
        Typeface type = Typeface.createFromAsset(getAssets(), fontPath);
        aboutus.setTypeface(type);

        animBounceH = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.bounce);
        animBounceH.setAnimationListener(SplashScreen.this);
        aboutus.setVisibility(View.VISIBLE);
        aboutus.startAnimation(animBounceH);

        String fontPath1 = "BluePlateSpecialNF.ttf";
        TextView aboutus1 = findViewById(R.id.textView4);
        Typeface type1 = Typeface.createFromAsset(getAssets(), fontPath1);
        aboutus1.setTypeface(type1);

        animBounceP = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.bounce);
        animBounceP.setAnimationListener(SplashScreen.this);
        aboutus1.setVisibility(View.VISIBLE);
        aboutus1.startAnimation(animBounceP);
        createShortcutIcon();

        String fontPath2 = "gunplay rg.ttf";
        TextView aboutus2 = findViewById(R.id.textView7);
        Typeface type2 = Typeface.createFromAsset(getAssets(), fontPath2);
        aboutus2.setTypeface(type2);

        animBouncePMS = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.bounce);
        animBouncePMS.setAnimationListener(SplashScreen.this);
        aboutus2.setVisibility(View.VISIBLE);
        aboutus2.startAnimation(animBouncePMS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            final String[] requestBasicPermissions = {
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.GET_ACCOUNTS, Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.POST_NOTIFICATIONS
            };
            boolean hasFineLocation =
                    RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.ACCESS_FINE_LOCATION);
            boolean hasGetAcc =
                    RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.GET_ACCOUNTS);
            boolean hasPostNotification = RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.POST_NOTIFICATIONS);
            boolean hasBluetooth = RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.BLUETOOTH_CONNECT);
            boolean hasStorage = RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.MANAGE_EXTERNAL_STORAGE);
            if (!hasFineLocation && !hasGetAcc && !hasBluetooth && !hasStorage && !hasPostNotification) {
                RuntimePermissionUtil.requestPermission(SplashScreen.this, requestBasicPermissions, 100);
            }
        } else {
            final String[] requestBasicPermissions = {
                    Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.GET_ACCOUNTS, Manifest.permission.USE_FINGERPRINT, Manifest.permission.MANAGE_EXTERNAL_STORAGE
            };
            boolean hasFineLocation =
                    RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.ACCESS_FINE_LOCATION);
            boolean hasReadPhoneState =
                    RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.READ_PHONE_STATE);
            boolean hasGetAcc =
                    RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.GET_ACCOUNTS);
            boolean hasBluetooth = RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.BLUETOOTH_CONNECT);
            boolean hasStorage = RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.MANAGE_EXTERNAL_STORAGE);
            boolean hasFingerprint = RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.USE_FINGERPRINT);

            if (!hasFineLocation && !hasGetAcc && !hasReadPhoneState && !hasFingerprint && !hasBluetooth && !hasStorage) {

            } else {
                RuntimePermissionUtil.requestPermission(SplashScreen.this, requestBasicPermissions, 100);
            }
        }

        /*
         * Showing splash screen with a timer. This will be useful when you
         * want to show case your app logo / company
         */
        int SPLASH_TIME_OUT = 4000;
        new Handler().postDelayed(() -> {

            Intent i = new Intent(SplashScreen.this, WelcomeActivity.class);
            startActivity(i);

            finish();
        }, SPLASH_TIME_OUT);

    }

    @Override
    public void onAnimationEnd(Animation animation) {

        if (animation == animFadein) {

        }

    }

    @Override
    public void onAnimationRepeat(Animation animation) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onAnimationStart(Animation animation) {
        // TODO Auto-generated method stub

    }

    // Creates shortcut on Android widget screen
    private void createShortcutIcon() {

        // Checking if ShortCut was already added
        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
        boolean shortCutWasAlreadyAdded = sharedPreferences.getBoolean(PREF_KEY_SHORTCUT_ADDED, false);
        if (shortCutWasAlreadyAdded) return;

        Intent shortcutIntent = new Intent(getApplicationContext(), SplashScreen.class);
        shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        Intent addIntent = new Intent();
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, "AdminApp");
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, Intent.ShortcutIconResource.fromContext(getApplicationContext(), R.drawable.primesaleslogo));
        addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        getApplicationContext().sendBroadcast(addIntent);

        // Remembering that ShortCut was already added
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(PREF_KEY_SHORTCUT_ADDED, true);
        editor.apply();
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }

}
