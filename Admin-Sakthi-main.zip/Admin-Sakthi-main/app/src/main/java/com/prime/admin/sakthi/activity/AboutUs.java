package com.prime.admin.sakthi.activity;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.prime.admin.sakthi.BuildConfig;
import com.prime.admin.sakthi.R;

public class AboutUs extends AppCompatActivity {
    TextView textVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        setContentView(R.layout.activity_about_us);
        textVersion = findViewById(R.id.text_version);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ImageView waveHead = findViewById(R.id.wave_head);
        ObjectAnimator waveAnimation = ObjectAnimator.ofFloat(
                waveHead, "scaleY", 1f, 0.8f, 1f);

        // Set animation duration and repeat mode
        waveAnimation.setDuration(1000); // Adjust the duration as needed
        waveAnimation.setRepeatMode(ObjectAnimator.REVERSE);
        waveAnimation.setRepeatCount(ObjectAnimator.INFINITE);

        textVersion.setText(BuildConfig.VERSION_NAME);

        // Start the wave animation
        waveAnimation.start();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }
}