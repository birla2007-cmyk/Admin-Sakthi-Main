package com.prime.admin.sakthi.activity.SQLiteQrDirectDeliveredScan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;
import com.prime.admin.sakthi.activity.qr.MainActivity;
import com.prime.admin.sakthi.model.DriverBillCloseInformationRespone;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.io.File;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QrDirectDeliveredScanList extends AppCompatActivity {

    private final String filter = "";
    ProgressDialog progressDialog;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private QrDirectDeliveredScanListAdapter adapter;
    private QrDirectDeliveredScanListAdapter qrCompanyListAdapter;
    private LinearLayoutManager linearLayoutManager;
    private QrDirectDeliveredScanDBHelper dbHelper;
    private List<QrDirectDeliveredScan> mPeopleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_company_scan_list);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRecyclerView = (RecyclerView) findViewById(R.id.card_recycler_view);

        mRecyclerView.setHasFixedSize(true);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        populaterecyclerView(filter);

        dbHelper = new QrDirectDeliveredScanDBHelper(QrDirectDeliveredScanList.this);
        dbHelper.countTable();

//        Log.d("ManikandanKRM1994", ""+dbHelper.countTable());

    }

    private void populaterecyclerView(String filter) {
        dbHelper = new QrDirectDeliveredScanDBHelper(this);
        adapter = new QrDirectDeliveredScanListAdapter(dbHelper.peopleList(filter), this, mRecyclerView);
        mRecyclerView.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        ///loadData();
    }

    public void QRDirectDelivered() {

        List<QrDirectDeliveredScan> QrDirectDeliveredScan = dbHelper.getAllQrDirectDeliveredData();

        for (QrDirectDeliveredScan QRDDS : QrDirectDeliveredScan) {
            QrDirectDeliveredScan QrDirectDeliveredScans = new QrDirectDeliveredScan();

            String Qr_Data = QRDDS.getQr_data();
            String Qr_Scan_Date = QRDDS.getQr_scan_date();
            String Qr_Image_Path = QRDDS.getQr_image_path();
            long Qr_Company_ID = QRDDS.getQr_company_id();

            Common.Data1 = Qr_Company_ID;

            File imagefile = new File(Qr_Image_Path);
            RequestBody reqBody = RequestBody.create(MediaType.parse("multipart/form-file"), imagefile);
            MultipartBody.Part partImage = MultipartBody.Part.createFormData("image", imagefile.getName(), reqBody);
            RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), imagefile.getName());
            RequestBody filename1 = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(Qr_Data));
            String baseUrl = Utils.getBaseUrl(this);
            ApiClient.getClient(baseUrl).setQrDirectDeliveredScan(partImage, filename, filename1).enqueue(new QrDirectDeliveredScanList.QrDirectDeliveredListData());

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.qrcompany_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            progressDialog = new ProgressDialog(QrDirectDeliveredScanList.this);
            progressDialog.setMessage("Loading..."); // Setting Message
            progressDialog.setTitle("Submit Status"); // Setting Title
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
            progressDialog.show(); // Display Progress Dialog

            dbHelper = new QrDirectDeliveredScanDBHelper(QrDirectDeliveredScanList.this);
//            Log.d("ManikandanKRM1994", ""+dbHelper.countTable());

            if (dbHelper.countTable() == 0) {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(QrDirectDeliveredScanList.this, "No Record Found",
                        Toast.LENGTH_LONG).show();
            } else {
                QRDirectDelivered();
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);
    }

    class QrDirectDeliveredListData implements Callback<DriverBillCloseInformationRespone> {

        QrDirectDeliveredListData() {

        }

        @Override
        public void onResponse(Call<DriverBillCloseInformationRespone> call, Response<DriverBillCloseInformationRespone> response) {
            System.out.println("Entering");
            int success = ((DriverBillCloseInformationRespone) response.body()).getSuccess();
            String messsge = ((DriverBillCloseInformationRespone) response.body()).getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonse", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                dbHelper = new QrDirectDeliveredScanDBHelper(QrDirectDeliveredScanList.this);
                Log.d("ManikandanKRM1994", "" + dbHelper.countTable());

                if (dbHelper.countTable() == 0) {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    Toast.makeText(QrDirectDeliveredScanList.this, "Finished.. ! No Record Found",
                            Toast.LENGTH_LONG).show();
                } else {
                    progressDialog = new ProgressDialog(QrDirectDeliveredScanList.this);
                    progressDialog.setMessage("Loading..."); // Setting Message
                    progressDialog.setTitle("Submit Status"); // Setting Title
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                    progressDialog.show(); // Display Progress Dialog

                    QrDirectDeliveredScanDBHelper dbHelper = new QrDirectDeliveredScanDBHelper(QrDirectDeliveredScanList.this);
                    dbHelper.deletePersonRecord(Common.Data1, QrDirectDeliveredScanList.this);

                    populaterecyclerView(filter);

                    QRDirectDelivered();
                }

            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(QrDirectDeliveredScanList.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(QrDirectDeliveredScanList.this, MainActivity.class));
                                QrDirectDeliveredScanList.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(QrDirectDeliveredScanList.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(QrDirectDeliveredScanList.this, MainActivity.class));
                                QrDirectDeliveredScanList.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();
            }
        }

        @Override
        public void onFailure(Call<DriverBillCloseInformationRespone> call, Throwable t) {
            Log.d("ManikandanKRM1994", "yyu" + "\t" + t.toString());
        }
    }

}