package com.prime.admin.sakthi.activity.SQLiteQrCompanyScan;

/**
 * Created by Ronsoft on 11/13/2017.
 */

public class QrCompany {

    private long qr_company_id;
    private String qr_data;
    private String qr_scan_date;
    private String qr_image_path;

    public QrCompany() {

    }

    public QrCompany(String qr_data, String qr_scan_date, String qr_image_path) {
        this.qr_data = qr_data;
        this.qr_scan_date = qr_scan_date;
        this.qr_image_path = qr_image_path;
    }

    public QrCompany(long qr_company_id, String qr_data, String qr_scan_date, String qr_image_path) {
        this.qr_company_id = qr_company_id;
        this.qr_data = qr_data;
        this.qr_scan_date = qr_scan_date;
        this.qr_image_path = qr_image_path;
    }

    public long getQr_company_id() {
        return qr_company_id;
    }

    public void setQr_company_id(long qr_company_id) {
        this.qr_company_id = qr_company_id;
    }

    public String getQr_data() {
        return qr_data;
    }

    public void setQr_data(String qr_data) {
        this.qr_data = qr_data;
    }

    public String getQr_scan_date() {
        return qr_scan_date;
    }

    public void setQr_scan_date(String qr_scan_date) {
        this.qr_scan_date = qr_scan_date;
    }

    public String getQr_image_path() {
        return qr_image_path;
    }

    public void setQr_image_path(String qr_image_path) {
        this.qr_image_path = qr_image_path;
    }

}
