package com.prime.admin.sakthi.model;

/**
 * Created by Admin on 11/16/2016.
 */

import com.google.gson.annotations.SerializedName;

public class DriverBillTakenDetails {

    @SerializedName("bill_date")
    String bill_date;
    @SerializedName("driver_id")
    String driver_id;
    @SerializedName("sales_order_id")
    String sales_order_id;
    @SerializedName("status")
    String status;
    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getBill_date() {
        return bill_date;
    }

    public void setBill_date(String bill_date) {
        this.bill_date = bill_date;
    }

    public String getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(String driver_id) {
        this.driver_id = driver_id;
    }

    public String getSales_order_id() {
        return sales_order_id;
    }

    public void setSales_order_id(String sales_order_id) {
        this.sales_order_id = sales_order_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
