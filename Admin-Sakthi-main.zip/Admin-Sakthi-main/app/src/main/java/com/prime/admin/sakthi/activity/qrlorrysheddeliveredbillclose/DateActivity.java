package com.prime.admin.sakthi.activity.qrlorrysheddeliveredbillclose;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity QR";
    String class_check = "", qr_data = "", qr_data_date = "", qr_datas = "";
    ProgressDialog progressDialog;
    String DataQr, DataDate, Data1, Data2, Datadt;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    TextView tv_balance_amount_val, tv_current_status_val, tv_selected_date_val, tv_changing_status_val, tv_heading;
    Button date_confirm;
    EditText edittext_date;

    SimpleDateFormat sdfs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker_fo);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        edittext_date = (EditText) findViewById(R.id.edittext_date);
        date_confirm = (Button) findViewById(R.id.date_confirm);

        sdfs = new SimpleDateFormat("yyyy-MM-dd");
        Common.DeliveredBillCLoseDate = sdfs.format(new Date());
        edittext_date.setText(Common.DeliveredBillCLoseDate);

        if (edittext_date.getText().equals("Select Date")) {
            date_confirm.setVisibility(View.GONE);
        } else {
            date_confirm.setVisibility(View.VISIBLE);
        }

        sdfs = new SimpleDateFormat("yyyy-MM-dd");

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

            private void updateLabel() {
                String myFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                edittext_date.setText(sdf.format(myCalendar.getTime()));
                Common.DeliveredBillCLoseDate = sdf.format(myCalendar.getTime());
            }
        };

        edittext_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(DateActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        date_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DateActivity.this, DecoderActivity.class));
                DateActivity.this.finish();
            }
        });

    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }

}
