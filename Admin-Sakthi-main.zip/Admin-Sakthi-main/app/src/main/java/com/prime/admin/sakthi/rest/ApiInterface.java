package com.prime.admin.sakthi.rest;

import com.prime.admin.sakthi.model.DriverBillCloseInformationRespone;
import com.prime.admin.sakthi.model.DriverBillCloseWithNoImgInformationRespone;
import com.prime.admin.sakthi.model.DriverBillTakenDetails;
import com.prime.admin.sakthi.model.DriverInfoResponse;
import com.prime.admin.sakthi.model.OrResponseApiModel;
import com.prime.admin.sakthi.model.QrDataInformationRespone;
import com.prime.admin.sakthi.model.QrInformation;
import com.prime.admin.sakthi.model.SalesmanTrackInsertInformationRespone;
import com.prime.admin.sakthi.model.SalesmanTrackUpdateInformationRespone;
import com.prime.admin.sakthi.model.UserInformation;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiInterface {

//    @Multipart
//    @POST("apiimage.php")
//    Call<OrResponseApiModel> setQrSalesmanScan (@Part MultipartBody.Part image, @Part("image") RequestBody name, @Part("sales_order_id") RequestBody sales_order_id, @Part("status") RequestBody status, @Part("date") RequestBody date);

//    @Multipart
//    @POST("apidriverbillclose.php")
//    Call<DriverBillCloseInformationRespone> setDeliveredBillClose (@Part MultipartBody.Part image, @Part("image") RequestBody name, @Part("sales_order_id") RequestBody sales_order_id, @Part("status") RequestBody status, @Part("date") RequestBody date);

    @Multipart
    @POST("api/apiinvoiceimage.php")
    Call<OrResponseApiModel> setQrSalesmanScan(@Part MultipartBody.Part image, @Part("image") RequestBody name, @Part("sales_order_id") RequestBody sales_order_id);

    @Multipart
    @POST("api/apidriverbillimage.php")
    Call<DriverBillCloseInformationRespone> setQrDirectDeliveredScan(@Part MultipartBody.Part image, @Part("image") RequestBody name, @Part("sales_order_id") RequestBody sales_order_id);

    @Multipart
    @POST("api/apidriverbillimage.php")
    Call<DriverBillCloseInformationRespone> setQrLsDeliveredScan(@Part MultipartBody.Part image, @Part("image") RequestBody name, @Part("sales_order_id") RequestBody sales_order_id);

    @FormUrlEncoded
    @POST("api/apidriverbillclose.php")
    Call<DriverBillCloseInformationRespone> setQrDirectDeliveredScanData(@Field("sales_order_id") String str1, @Field("status") String str2);

    @FormUrlEncoded
    @POST("api/apidriverbillclose.php")
    Call<DriverBillCloseInformationRespone> setQrLsDeliveredScanData(@Field("sales_order_id") String str1, @Field("status") String str2);

    @FormUrlEncoded
    @POST("api/apiimage.php")
    Call<OrResponseApiModel> qruploadImage(@Field("sales_order_id") String str1, @Field("status") String str2);

    @FormUrlEncoded
    @POST("api/apiuserlogin.php")
    Call<UserInformation> getUserInfo(@Field("userphone") String str1, @Field("password") String str2);

    @FormUrlEncoded
    @POST("api/apidriverbillclosenoimg.php")
    Call<DriverBillCloseWithNoImgInformationRespone> setDeliveredBillCloseNoImg(@Field("sales_order_id") String str1, @Field("status") String str2);

    @FormUrlEncoded
    @POST("api/apistatuswithoutimage.php")
    Call<OrResponseApiModel> setUserQRWithoutImgCOmpanyInfo(@Field("sales_order_id") String str2, @Field("status") String str3, @Field("date") String str1);

    @FormUrlEncoded
    @POST("api/apibilltakenstatus.php")
    Call<QrInformation> setQrInfo(@Field("sid") String str2, @Field("status") String str3, @Field("billdate") String str4);

    @FormUrlEncoded
    @POST("api/apidriverbilltaken.php")
    Call<DriverBillTakenDetails> setDriverBillTaken(@Field("sales_order_id") String str2, @Field("status") String str3, @Field("bill_date") String str4, @Field("driver_id") String str5);

    @FormUrlEncoded
    @POST("api/apiqrcodedata.php")
    Call<QrDataInformationRespone> setQrDataInfo(@Field("id") String str2);

    @FormUrlEncoded
    @POST("api/apinewlocation.php")
    Call<SalesmanTrackInsertInformationRespone> setSalesmanTrackInsertInfo(@Field("id") String str1, @Field("date") String str2, @Field("time") String str3, @Field("longitude_number") String str4, @Field("latitude_number") String str5, @Field("address") String str6);

    @FormUrlEncoded
    @POST("api/apiupdatelocation.php")
    Call<SalesmanTrackUpdateInformationRespone> setSalesmanTrackUpdateInfo(@Field("id") String str1, @Field("date") String str2, @Field("time") String str3, @Field("longitude_number") String str4, @Field("latitude_number") String str5, @Field("address") String str6);

    @GET("api/apidriver.php")
    Call<DriverInfoResponse> getDriverInfo();
}
