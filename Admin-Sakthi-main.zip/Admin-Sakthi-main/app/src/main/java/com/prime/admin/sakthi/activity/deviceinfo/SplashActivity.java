package com.prime.admin.sakthi.activity.deviceinfo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.prime.admin.sakthi.R;

public class SplashActivity extends AppCompatActivity {

    private static final String[] requestBasicPermissions = {
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.GET_ACCOUNTS, Manifest.permission.USE_FINGERPRINT
    };
    private boolean launched = false;

    private static void setFullScreen(Activity activity) {
        activity.getWindow()
                .setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        setFullScreen(this);

        setContentView(R.layout.activity_device_info_splash);

        boolean hasFineLocation =
                RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.ACCESS_FINE_LOCATION);
        boolean hasReadPhoneState =
                RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.READ_PHONE_STATE);
        boolean hasGetAcc =
                RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.GET_ACCOUNTS);
        boolean hasFingerprint = false;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            hasFingerprint =
                    RuntimePermissionUtil.checkPermissonGranted(this, Manifest.permission.USE_FINGERPRINT);
        }

        if (hasFineLocation && hasGetAcc && hasReadPhoneState && hasFingerprint) {
            loadMainActivity();
        } else {
            RuntimePermissionUtil.requestPermission(SplashActivity.this, requestBasicPermissions, 100);
        }

        final Button btnReqPermission = findViewById(R.id.btn_req);
        btnReqPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RuntimePermissionUtil.requestPermission(SplashActivity.this, requestBasicPermissions, 100);
            }
        });
    }

    private void loadMainActivity() {
        startActivity(new Intent(SplashActivity.this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        launched = true;
        finish();
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull final String[] permissions,
                                           @NonNull final int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            RuntimePermissionUtil.onRequestPermissionsResult(grantResults, new RPResultListener() {
                @Override
                public void onPermissionGranted() {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED
                            && grantResults[1] == PackageManager.PERMISSION_GRANTED
                            && grantResults[2] == PackageManager.PERMISSION_GRANTED
                            && grantResults[3] == PackageManager.PERMISSION_GRANTED
                            && !launched) {
                        loadMainActivity();
                    }
                }

                @Override
                public void onPermissionDenied() {

                }
            });
        }
    }
}
