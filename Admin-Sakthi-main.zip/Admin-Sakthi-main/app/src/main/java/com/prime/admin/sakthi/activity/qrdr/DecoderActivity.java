package com.prime.admin.sakthi.activity.qrdr;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dlazaro66.qrcodereaderview.QRCodeReaderView;
import com.dlazaro66.qrcodereaderview.QRCodeReaderView.OnQRCodeReadListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;
import com.prime.admin.sakthi.activity.RecyclerTouchListener;
import com.prime.admin.sakthi.adapter.DialogDriverListAdapter;
import com.prime.admin.sakthi.model.DriverInfoDetails;
import com.prime.admin.sakthi.model.DriverInfoResponse;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DecoderActivity extends AppCompatActivity
        implements ActivityCompat.OnRequestPermissionsResultCallback, OnQRCodeReadListener {

    private static final int MY_PERMISSION_REQUEST_CAMERA = 0;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    String DateSelect, Drivername, Driverid;
    ArrayList<DriverInfoDetails> items;
    DriverInfoDetails itemInfo;
    String DriverID = "", DriverName = "";
    ProgressDialog progressDialog;
    SearchView search;
    RecyclerView rv;
    DialogDriverListAdapter iadapter;
    private ViewGroup mainLayout;
    private TextView resultTextView, driver_name;
    private QRCodeReaderView qrCodeReaderView;
    private CheckBox flashlightCheckBox;
    private CheckBox enableDecodingCheckBox;
    private CheckBox reme;
    private CheckBox remes;
    private PointsOverlayView pointsOverlayView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_decoder);

        mainLayout = (ViewGroup) findViewById(R.id.main_layout);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            initQRCodeReaderView();
        } else {
            requestCameraPermission();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (qrCodeReaderView != null) {
            qrCodeReaderView.startCamera();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (qrCodeReaderView != null) {
            qrCodeReaderView.stopCamera();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != MY_PERMISSION_REQUEST_CAMERA) {
            return;
        }

        if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Snackbar.make(mainLayout, "Camera permission was granted.", Snackbar.LENGTH_SHORT).show();
            initQRCodeReaderView();
        } else {
            Snackbar.make(mainLayout, "Camera permission request was denied.", Snackbar.LENGTH_SHORT)
                    .show();
        }
    }

    // Called when a QR is decoded
    // "text" : the text encoded in QR
    // "points" : points where QR control points are placed
    @Override
    public void onQRCodeRead(String text, PointF[] points) {
        if (driver_name.getText().toString().equals("Driver_Name")) {

            Toast.makeText(DecoderActivity.this, "Please Choose Driver Name",
                    Toast.LENGTH_LONG).show();

        } else {
            Intent i1 = new Intent(DecoderActivity.this, MainActivity.class);

            Log.d("ManikandanKRM", "" + Common.DateForDriverBillTaken);
            Log.d("ManikandanKRM", "" + Common.DriverNameForBllTaken);
            Log.d("ManikandanKRM", "" + Common.DriverIDForBllTaken);
            i1.putExtra("qr", "1");
            i1.putExtra("qr_data", text);
            i1.putExtra("qr_data_date", Common.DateForDriverBillTaken);
            i1.putExtra("qr_data_drname", Common.DriverNameForBllTaken);
            i1.putExtra("qr_data_drid", Common.DriverIDForBllTaken);
            startActivity(i1);
            DecoderActivity.this.finish();
        }
        pointsOverlayView.setPoints(points);
    }

    private void requestCameraPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
            Snackbar.make(mainLayout, "Camera access is required to display the camera preview.",
                    Snackbar.LENGTH_INDEFINITE).setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityCompat.requestPermissions(DecoderActivity.this, new String[]{
                            Manifest.permission.CAMERA
                    }, MY_PERMISSION_REQUEST_CAMERA);
                }
            }).show();
        } else {
            Snackbar.make(mainLayout, "Permission is not available. Requesting camera permission.",
                    Snackbar.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.CAMERA
            }, MY_PERMISSION_REQUEST_CAMERA);
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }

    public void popitem() {
        progressDialog = new ProgressDialog(DecoderActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Show Driver List"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        String baseUrl = Utils.getBaseUrl(this);
        ApiClient.getClient(baseUrl).getDriverInfo().enqueue(new DecoderActivity.ShowItemList());
    }

    public void savePreferences(String key, String value) {
        SharedPreferences sharedPreferences = getPreferences();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public SharedPreferences getPreferences() {
        return this.getSharedPreferences("salesapps", Context.MODE_PRIVATE);
    }

    public String loadPreferences(String key) {
        try {
            SharedPreferences sharedPreferences = getPreferences();
            String strSavedMemo = sharedPreferences.getString(key, "");
            return strSavedMemo;
        } catch (NullPointerException nullPointerException) {
            return null;
        }
    }

    private void initQRCodeReaderView() {
        View content = getLayoutInflater().inflate(R.layout.content_decoderdbt, mainLayout, true);

        qrCodeReaderView = (QRCodeReaderView) content.findViewById(R.id.qrdecoderview);
        resultTextView = (TextView) content.findViewById(R.id.result_text_view);
        driver_name = (TextView) content.findViewById(R.id.driver_name);
        flashlightCheckBox = (CheckBox) content.findViewById(R.id.flashlight_checkbox);
        enableDecodingCheckBox = (CheckBox) content.findViewById(R.id.enable_decoding_checkbox);
        reme = (CheckBox) content.findViewById(R.id.reme);
        remes = (CheckBox) content.findViewById(R.id.remes);
        pointsOverlayView = (PointsOverlayView) content.findViewById(R.id.points_overlay_view);

        String class_check, qr_data, qr_data_date;


        //Delivery Date Set In Editext

        if (Common.DateForDriverBillTaken.isEmpty()) {
            SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd");
            Common.DateForDriverBillTaken = sdfs.format(new Date());
            resultTextView.setText(Common.DateForDriverBillTaken);
        } else {
            resultTextView.setText(Common.DateForDriverBillTaken);
        }

        if (Common.DriverNameForBllTaken.isEmpty()) {
            driver_name.setText("Driver_Name");
        } else {
            driver_name.setText(Common.DriverNameForBllTaken);
        }

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

            private void updateLabel() {
                String myFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                Common.DateForDriverBillTaken = sdf.format(myCalendar.getTime());
                resultTextView.setText(Common.DateForDriverBillTaken);
            }
        };

        driver_name.setOnClickListener(view -> popitem());

        resultTextView.setOnClickListener(view -> {
            reme.setChecked(true);
            new DatePickerDialog(DecoderActivity.this, date, myCalendar
                    .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                    myCalendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        enableDecodingCheckBox.setVisibility(View.GONE);

        qrCodeReaderView.setAutofocusInterval(2000L);
        qrCodeReaderView.setOnQRCodeReadListener(this);
        qrCodeReaderView.setBackCamera();
        flashlightCheckBox.setOnCheckedChangeListener((compoundButton, isChecked) -> qrCodeReaderView.setTorchEnabled(isChecked));
        enableDecodingCheckBox.setOnCheckedChangeListener((compoundButton, isChecked) -> qrCodeReaderView.setQRDecodingEnabled(isChecked));
        qrCodeReaderView.startCamera();
    }

    class ShowItemList implements Callback<DriverInfoResponse> {

        ShowItemList() {

        }

        public void onResponse(Call<DriverInfoResponse> call, Response<DriverInfoResponse> response) {
            if (response.isSuccessful()) {
                int success = ((DriverInfoResponse) response.body()).getSuccess();
                if (success == 1) {
                    items = ((DriverInfoResponse) response.body()).getResults();
                    Gson gson = new Gson();
                    String valuesString = gson.toJson(items);
                    System.out.println(valuesString);
//                session.setItems(valuesString);
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    final Dialog dialog = new Dialog(DecoderActivity.this);
                    dialog.setContentView(R.layout.fragment_item_list);
                    search = (SearchView) dialog.findViewById(R.id.search);
                    rv = (RecyclerView) dialog.findViewById(R.id.card_recycler_view_item_list);
                    rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    iadapter = new DialogDriverListAdapter(getApplicationContext(), items);
                    rv.setAdapter(iadapter);
                    dialog.show();

                    Toolbar toolbar2 = (Toolbar) dialog.findViewById(R.id.toolbar4);
                    toolbar2.setTitle("Driver List");

                    search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                        @Override
                        public boolean onQueryTextSubmit(String newText) {
                            return false;
                        }

                        @Override
                        public boolean onQueryTextChange(String query) {
                            Log.i("well", " this worked");
                            iadapter.getFilter().filter(query);
                            return false;
                        }
                    });

                    rv.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rv, new RecyclerTouchListener.ClickListener() {
                        @Override
                        public void onClick(View view, int position) {
                            itemInfo = items.get(position);

                            Common.DriverIDForBllTaken = String.valueOf(itemInfo.getDriver_id());
                            Log.d("Driver", "" + Common.DriverIDForBllTaken);

                            Common.DriverNameForBllTaken = itemInfo.getDriver_name();
                            Log.d("Driver", "" + Common.DriverNameForBllTaken);

                            dialog.dismiss();

                            driver_name.setText("" + Common.DriverNameForBllTaken);

                        }

                        @Override
                        public void onLongClick(View view, int position) {

                        }
                    }));

                    Log.d("jjj", "Number of items received: " + items.size());
                } else if (success == 0) {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    String message = response.body().getMessage();

                    new SweetAlertDialog(DecoderActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> sDialog.cancel())
                            .show();
                } else if (success == 2) {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    String message = response.body().getMessage();

                    new SweetAlertDialog(DecoderActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> sDialog.cancel())

                            .show();
                } else {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    new SweetAlertDialog(DecoderActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> sDialog.cancel())
                            .show();
                }
            }
        }

        public void onFailure(Call<DriverInfoResponse> call, Throwable t) {

        }
    }
}