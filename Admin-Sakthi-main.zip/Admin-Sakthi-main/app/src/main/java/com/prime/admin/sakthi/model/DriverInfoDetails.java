package com.prime.admin.sakthi.model;

/**
 * Created by Admin on 11/16/2016.
 */

import com.google.gson.annotations.SerializedName;

public class DriverInfoDetails {

    @SerializedName("driver_id")
    int driver_id;
    @SerializedName("driver_name")
    String driver_name;

    public int getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(int driver_id) {
        this.driver_id = driver_id;
    }

    public String getDriver_name() {
        return driver_name;
    }

    public void setDriver_name(String driver_name) {
        this.driver_name = driver_name;
    }

}
