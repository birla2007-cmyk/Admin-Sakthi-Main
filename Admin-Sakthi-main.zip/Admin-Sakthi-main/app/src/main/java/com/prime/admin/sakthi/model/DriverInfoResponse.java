package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class DriverInfoResponse {
    @SerializedName("drivers")
    private ArrayList<DriverInfoDetails> results;
    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public int getSuccess() {
        return this.success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public ArrayList<DriverInfoDetails> getResults() {
        return this.results;
    }

    public void setResults(ArrayList<DriverInfoDetails> results) {
        this.results = results;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}




