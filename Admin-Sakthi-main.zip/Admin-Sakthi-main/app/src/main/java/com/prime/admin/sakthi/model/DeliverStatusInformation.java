package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Admin on 12/30/2016.
 */

public class DeliverStatusInformation {
    @SerializedName("soid")
    int soid;
    @SerializedName("sign")
    String sign;
    @SerializedName("t_dte")
    String t_dte;
    @SerializedName("success")
    int success;
    @SerializedName("message")
    String messsge;

    public int getSoid() {
        return soid;
    }

    public void setSoid(int soid) {
        this.soid = soid;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getMesssge() {
        return messsge;
    }

    public void setMesssge(String messsge) {
        this.messsge = messsge;
    }

    public String getT_dte() {
        return t_dte;
    }

    public void setT_dte(String t_dte) {
        this.t_dte = t_dte;
    }

}
