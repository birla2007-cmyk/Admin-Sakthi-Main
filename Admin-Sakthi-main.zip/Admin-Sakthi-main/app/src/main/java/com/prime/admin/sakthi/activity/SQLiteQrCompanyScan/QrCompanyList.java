package com.prime.admin.sakthi.activity.SQLiteQrCompanyScan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;
import com.prime.admin.sakthi.activity.qr.MainActivity;
import com.prime.admin.sakthi.model.OrResponseApiModel;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.io.File;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QrCompanyList extends AppCompatActivity {

    ProgressDialog progressDialog;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private QrCompanyListAdapter adapter;
    private QrCompanyListAdapter qrCompanyListAdapter;
    private LinearLayoutManager linearLayoutManager;
    private QrCompanyDBHelper dbHelper;
    private final String filter = "";
    private List<QrCompany> mPeopleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_company_scan_list);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRecyclerView = (RecyclerView) findViewById(R.id.card_recycler_view);

        mRecyclerView.setHasFixedSize(true);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        populaterecyclerView(filter);

        //QrCompanyDBHelper.countTable();

        dbHelper = new QrCompanyDBHelper(QrCompanyList.this);
        dbHelper.countTable();

        Log.d("ManikandanKRM1994", "" + dbHelper.countTable());

    }

    private void populaterecyclerView(String filter) {
        dbHelper = new QrCompanyDBHelper(this);
        adapter = new QrCompanyListAdapter(dbHelper.peopleList(filter), this, mRecyclerView);
        mRecyclerView.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        ///loadData();
    }

    public void QRCompany() {

        List<QrCompany> QrCompany = dbHelper.getAllQrCompanyData();
        for (QrCompany QRC : QrCompany) {
            QrCompany QrCompanys = new QrCompany();

            String Qr_Data = QRC.getQr_data();
            String Qr_Scan_Date = QRC.getQr_scan_date();
            String Qr_Image_Path = QRC.getQr_image_path();
            long Qr_Company_ID = QRC.getQr_company_id();

            Common.Data1 = Qr_Company_ID;

            File imagefile = new File(Qr_Image_Path);
            RequestBody reqBody = RequestBody.create(MediaType.parse("multipart/form-file"), imagefile);
            MultipartBody.Part partImage = MultipartBody.Part.createFormData("image", imagefile.getName(), reqBody);
            RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), imagefile.getName());
            RequestBody filename1 = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(Qr_Data));
            String baseUrl = Utils.getBaseUrl(this);
            ApiClient.getClient(baseUrl).setQrSalesmanScan(partImage, filename, filename1).enqueue(new QrCompanyList.QrCompanyListData());

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.qrcompany_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            progressDialog = new ProgressDialog(QrCompanyList.this);
            progressDialog.setMessage("Loading..."); // Setting Message
            progressDialog.setTitle("Submit Status"); // Setting Title
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
            progressDialog.show(); // Display Progress Dialog

            dbHelper = new QrCompanyDBHelper(QrCompanyList.this);
            Log.d("ManikandanKRM1994", "" + dbHelper.countTable());

            if (dbHelper.countTable() == 0) {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(QrCompanyList.this, "No Record Found",
                        Toast.LENGTH_LONG).show();
            } else {
                QRCompany();
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);
    }

    class QrCompanyListData implements Callback<OrResponseApiModel> {

        QrCompanyListData() {

        }

        @Override
        public void onResponse(Call<OrResponseApiModel> call, Response<OrResponseApiModel> response) {
            System.out.println("Entering");
            int success = ((OrResponseApiModel) response.body()).getSuccess();
            String messsge = ((OrResponseApiModel) response.body()).getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonse", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(QrCompanyList.this, "Status Submitted",
                        Toast.LENGTH_LONG).show();

                dbHelper = new QrCompanyDBHelper(QrCompanyList.this);
                Log.d("ManikandanKRM1994", "" + dbHelper.countTable());

                if (dbHelper.countTable() == 0) {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    Toast.makeText(QrCompanyList.this, "No Record Found",
                            Toast.LENGTH_LONG).show();
                } else {
                    progressDialog = new ProgressDialog(QrCompanyList.this);
                    progressDialog.setMessage("Loading..."); // Setting Message
                    progressDialog.setTitle("Submit Status"); // Setting Title
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                    progressDialog.show(); // Display Progress Dialog

                    QrCompanyDBHelper dbHelper = new QrCompanyDBHelper(QrCompanyList.this);
                    dbHelper.deletePersonRecord(Common.Data1, QrCompanyList.this);

                    populaterecyclerView(filter);

                    QRCompany();
                }

            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(QrCompanyList.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(QrCompanyList.this, MainActivity.class));
                                QrCompanyList.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(QrCompanyList.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(QrCompanyList.this, MainActivity.class));
                                QrCompanyList.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();
            }
        }

        @Override
        public void onFailure(Call<OrResponseApiModel> call, Throwable t) {
            Log.d("ManikandanKRM1994", "yyu" + "\t" + t.toString());
        }
    }

}