package com.prime.admin.sakthi.activity.qrdirectreturnbillclose;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.gson.Gson;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.model.DriverBillCloseDetails;
import com.prime.admin.sakthi.model.DriverBillCloseWithNoImgInformationRespone;
import com.prime.admin.sakthi.model.QrDataInformation;
import com.prime.admin.sakthi.model.QrDataInformationRespone;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.util.Utils;

import java.io.File;
import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity QR";
    final int REQUEST_GALLERY = 9544;
    String balanceAmount, deliveryType, deliverySign, driverStatus, billNo, class_check = "", qr_data = "", part_image;
    ProgressDialog progressDialog;
    TextView tv_balance_amount_val, tv_current_status_val, tv_bill_no_val, tv_selected_date_val, tv_selected_date, tv_changing_status_val, tv_heading;
    Button btn_back_to_qr_scan, btn_submit_status;
    ImageView Image;
    CardView card_view;
    LinearLayout btn, btnL;
    String Stat = "";
    String[] parts = new String[0];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultdlsrbc);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        tv_balance_amount_val = findViewById(R.id.tv_balance_amount_val);
        tv_current_status_val = findViewById(R.id.tv_current_status_val);
        tv_selected_date_val = findViewById(R.id.tv_selected_date_val);
        tv_selected_date = findViewById(R.id.tv_selected_date);
        tv_changing_status_val = findViewById(R.id.tv_changing_status_val);
        tv_heading = findViewById(R.id.tv_heading);
        tv_bill_no_val = findViewById(R.id.tv_bill_no_val);
        btn_back_to_qr_scan = findViewById(R.id.btn_back_to_qr_scan);
        btn_submit_status = findViewById(R.id.btn_submit_status);

        card_view = findViewById(R.id.card_view);
        Image = findViewById(R.id.Image);

        btn = findViewById(R.id.btn);
        btnL = findViewById(R.id.btnL);

        if (getIntent() != null) {
            class_check = getIntent().getStringExtra("qr");

            if (class_check.equalsIgnoreCase("1")) {
                qr_data = getIntent().getStringExtra("qr_data");
                parts = qr_data.split("-");
                qr_data = parts[0];
            }
        }
        Log.i("Kishore", "Im here");
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Scan For Driver Direct Return Bill Close"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        String baseUrl = Utils.getBaseUrl(this);
        ApiClient.getClientUpdate(parts[1], baseUrl).setQrDataInfo(qr_data).enqueue(new MainActivity.Receipt());


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "" + requestCode + "\t" + resultCode + "\t" + data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_GALLERY) {
                Uri dataimage = data.getData();
                String[] imageprojection = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(dataimage, imageprojection, null, null, null);

                if (cursor != null) {
                    cursor.moveToFirst();
                    int indexImage = cursor.getColumnIndex(imageprojection[0]);
                    part_image = cursor.getString(indexImage);

                    if (part_image != null) {
                        File image = new File(part_image);
                        Image.setImageBitmap(BitmapFactory.decodeFile(image.getAbsolutePath()));
                    }
                }
            }
        }
    }

    class Receipt implements Callback<QrDataInformationRespone> {

        Receipt() {

        }

        @Override
        public void onResponse(Call<QrDataInformationRespone> call, Response<QrDataInformationRespone> response) {
            System.out.println("Entering");
            Log.i("Kishore", "Response");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonsem", "" + success + "\t" + response);
            if (success == 1) {

                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);

                ArrayList<QrDataInformation> qritems = response.body().getResults();

                Gson gson = new Gson();
                String valuesString = gson.toJson(qritems);
                System.out.println(valuesString);

                Log.d("checkrepsonsem", "" + valuesString);

                Stat = "InCompany";

                for (int i = 0; i < qritems.size(); i++) {

                    balanceAmount = qritems.get(i).getBalance_Amount();

                    deliveryType = qritems.get(i).getDelivery_type();

                    deliverySign = qritems.get(i).getDelivered_sign();

                    driverStatus = qritems.get(i).getDriver_status();

                    billNo = qritems.get(i).getBill_no();

                    Log.d("checkrepsonsem", "" + balanceAmount);
                    Log.d("checkrepsonsem", "" + deliveryType);
                    Log.d("checkrepsonsem", "" + deliverySign);
                    Log.d("checkrepsonsem", "" + driverStatus);

                    if (balanceAmount == null && deliverySign == null && driverStatus == null) {

                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();

                        btn_submit_status.setVisibility(View.GONE);
                        card_view.setVisibility(View.GONE);

                        Image.setImageResource(R.drawable.closebutton);

                        btn_back_to_qr_scan.setOnClickListener(view -> {

                            startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                            finish();

                        });

                    } else if (balanceAmount.isEmpty() && deliverySign.isEmpty() && driverStatus.isEmpty()) {

                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();

                        btn_submit_status.setVisibility(View.GONE);
                        card_view.setVisibility(View.GONE);

                        Image.setImageResource(R.drawable.closebutton);

                        btn_back_to_qr_scan.setOnClickListener(view -> {

                            startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                            finish();

                        });

                    } else if (deliveryType.equals("direct delivery")) {

                        if (!deliverySign.equals("cancel")) {

                            if (deliverySign.equals("sent to delivery")) {

                                if (driverStatus.equals("incompany")) {

//                                    progressDialog.setCancelable(false);
                                    progressDialog.cancel();
                                    progressDialog.dismiss();

                                    Image.setVisibility(View.GONE);

                                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                            .setTitleText("Bill Already Scanned")
                                            .setConfirmText("Ok")
                                            .setConfirmClickListener(sDialog -> {
                                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                                MainActivity.this.finish();
                                                sDialog.cancel();
                                            })
                                            .show();

                                } else if (driverStatus.equals("indriver")) {

                                    progressDialog.setCancelable(false);
                                    progressDialog.dismiss();

                                    Image.setVisibility(View.GONE);

                                    tv_heading.setText("Direct Return Bill Close");
                                    tv_balance_amount_val.setText("" + balanceAmount);
                                    tv_current_status_val.setText("InDriver");
                                    tv_changing_status_val.setText("InCompany");
                                    tv_bill_no_val.setText("" + billNo);

                                    btn_back_to_qr_scan.setOnClickListener(view -> {

                                        startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                        finish();

                                    });

                                    btn_submit_status.setOnClickListener(view -> {

                                        progressDialog.setCancelable(false);
                                        progressDialog.dismiss();

                                        progressDialog = new ProgressDialog(MainActivity.this);
                                        progressDialog.setMessage("Loading..."); // Setting Message
                                        progressDialog.setTitle("Status Submit"); // Setting Title
                                        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                        progressDialog.show(); // Display Progress Dialog
                                        String baseUrl = Utils.getBaseUrl(MainActivity.this);
                                        ApiClient.getClientUpdate(parts[1], baseUrl).setDeliveredBillCloseNoImg(qr_data, Stat).enqueue(new QrDrReceipt());

                                    });


                                }
                            } else if (deliverySign.equals("delivered")) {

                                progressDialog.setCancelable(false);
                                progressDialog.dismiss();

                                Image.setVisibility(View.GONE);

                                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                        .setTitleText("Delivered Bill")
                                        .setConfirmText("Ok")
                                        .setConfirmClickListener(sDialog -> {
                                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                            MainActivity.this.finish();
                                            sDialog.cancel();
                                        })
                                        .show();

                            }
                        } else {
                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            Image.setVisibility(View.GONE);

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                    .setTitleText("Cancelled Bill")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(sDialog -> {
                                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                        MainActivity.this.finish();
                                        sDialog.cancel();
                                    })
                                    .show();
                        }
                    } else {

                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();

                        Image.setVisibility(View.GONE);

                        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText("Lorry Shed Bill")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(sDialog -> {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                })
                                .show();
                    }
                }

            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        })
                        .show();
            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        })
                        .show();
            }
        }

        @Override
        public void onFailure(Call<QrDataInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class QrDrReceipt implements Callback<DriverBillCloseWithNoImgInformationRespone> {

        QrDrReceipt() {

        }

        @Override
        public void onResponse(Call<DriverBillCloseWithNoImgInformationRespone> call, Response<DriverBillCloseWithNoImgInformationRespone> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonses", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(MainActivity.this, "Status Submitted",
                        Toast.LENGTH_LONG).show();

                Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);
                finish();

            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InCompany'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();
            }
        }

        @Override
        public void onFailure(Call<DriverBillCloseWithNoImgInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class Qr implements Callback<DriverBillCloseDetails> {

        Qr() {

        }

        @Override
        public void onResponse(Call<DriverBillCloseDetails> call, Response<DriverBillCloseDetails> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonse", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(MainActivity.this, "Status Submitted",
                        Toast.LENGTH_LONG).show();

                Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);
                finish();


            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InDriver'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InDriver'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();


            }
        }

        @Override
        public void onFailure(Call<DriverBillCloseDetails> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }
}
