package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Admin on 11/24/2016.
 */

public class QrDataInformation {

    @SerializedName("sales_order_number")
    String bill_no;

    @SerializedName("balance_amount")
    String balance_amount;

    @SerializedName("status")
    String status;

    @SerializedName("delivery_type")
    String delivery_type;

    @SerializedName("delivered_sign")
    String delivered_sign;

    @SerializedName("driver_status")
    String driver_status;

    @SerializedName("lorryshed_status")
    String lorrshed_status;

    public String getBill_no() {
        return bill_no;
    }

    public void setBill_no(String bill_no) {
        this.bill_no = bill_no;
    }

    public String getLorrshed_status() {
        return lorrshed_status;
    }

    public void setLorrshed_status(String lorrshed_status) {
        this.lorrshed_status = lorrshed_status;
    }

    public String getDelivery_type() {
        return delivery_type;
    }

    public void setDelivery_type(String delivery_type) {
        this.delivery_type = delivery_type;
    }

    public String getDriver_status() {
        return driver_status;
    }

    public void setDriver_status(String driver_status) {
        this.driver_status = driver_status;
    }

    public String getDelivered_sign() {
        return delivered_sign;
    }

    public void setDelivered_sign(String delivered_sign) {
        this.delivered_sign = delivered_sign;
    }

    public String getStatusm() {
        return status;
    }

    public void setStatusm(String status) {
        this.status = status;
    }

    public String getBalance_Amount() {
        return balance_amount;
    }

    public void setBalance_Amount(String balance_amount) {
        this.balance_amount = balance_amount;
    }

}
