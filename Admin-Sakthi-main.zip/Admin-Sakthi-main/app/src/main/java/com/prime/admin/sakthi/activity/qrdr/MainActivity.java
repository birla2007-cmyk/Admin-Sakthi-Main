package com.prime.admin.sakthi.activity.qrdr;

import static com.prime.admin.sakthi.util.Utils.makeNotification;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.RecyclerTouchListener;
import com.prime.admin.sakthi.adapter.DialogDriverListAdapter;
import com.prime.admin.sakthi.model.DriverBillTakenDetails;
import com.prime.admin.sakthi.model.DriverInfoDetails;
import com.prime.admin.sakthi.model.DriverInfoResponse;
import com.prime.admin.sakthi.model.QrDataInformation;
import com.prime.admin.sakthi.model.QrDataInformationRespone;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity QR";
    String DataQr, Data1, Data2, Data3, Data4, Data5, Datadt, class_check = "", qr_data_date = "", qr_data_drname = "", qr_data_drid = "", DataDate, qr_data = "", qr_datas = "";
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    SearchView search;
    RecyclerView rv;
    DialogDriverListAdapter iadapter;
    ArrayList<DriverInfoDetails> items;
    DriverInfoDetails itemInfo;
    String DriverID = "", DriverName = "";
    ProgressDialog progressDialog;
    TextView tv_balance_amount_val, tv_current_status_val, tv_bill_no_val, tv_selected_date_val, tv_changing_status_val, tv_heading, tv_Seelected_Driver_val;
    Button btn_back_to_qr_scan, btn_submit_status;
    CardView card_view;

    SimpleDateFormat sdfs;
    String[] parts = new String[0];
    String baseUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultdbt);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        baseUrl = Utils.getBaseUrl(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        tv_balance_amount_val = findViewById(R.id.tv_balance_amount_val);
        tv_current_status_val = findViewById(R.id.tv_current_status_val);
        tv_selected_date_val = findViewById(R.id.tv_selected_date_val);
        tv_changing_status_val = findViewById(R.id.tv_changing_status_val);
        tv_Seelected_Driver_val = findViewById(R.id.tv_Seelected_Driver_val);
        tv_heading = findViewById(R.id.tv_heading);
        btn_back_to_qr_scan = findViewById(R.id.btn_back_to_qr_scan);
        btn_submit_status = findViewById(R.id.btn_submit_status);
        card_view = findViewById(R.id.card_view);
        tv_bill_no_val = findViewById(R.id.tv_bill_no_val);
        sdfs = new SimpleDateFormat("yyyy-MM-dd");

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

            private void updateLabel() {
                String myFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                tv_selected_date_val.setText(sdf.format(myCalendar.getTime()));
                qr_data_date = sdf.format(myCalendar.getTime());
            }
        };


        if (getIntent() != null) {
            class_check = getIntent().getStringExtra("qr");

            if (class_check.equalsIgnoreCase("1")) {
                qr_data = getIntent().getStringExtra("qr_data");
                qr_data_date = getIntent().getStringExtra("qr_data_date");
                qr_data_drname = getIntent().getStringExtra("qr_data_drname");
                qr_data_drid = getIntent().getStringExtra("qr_data_drid");
                parts = qr_data.split("-");
                DataQr = parts[0];
                qr_data = parts[0];
                //Toast.makeText(MainActivity.this,"Qr_Data - " + qr_data + "Date - " + qr_data_date + "drname - " + qr_data_drname + "drid - " + qr_data_drid , Toast.LENGTH_SHORT).show();
            }
        }

        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Scan For Driver Bill Taken"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog

        ApiClient.getClientUpdate(parts[1], baseUrl).setQrDataInfo(qr_data).enqueue(new MainActivity.Receipt());

    }

    public void popitem() {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Show Driver List"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        ApiClient.getClient(baseUrl).getDriverInfo().enqueue(new MainActivity.ShowItemList());
    }

    class Receipt implements Callback<QrDataInformationRespone> {

        Receipt() {

        }

        @Override
        public void onResponse(Call<QrDataInformationRespone> call, Response<QrDataInformationRespone> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonsem", "" + success + "\t" + response);
            if (success == 1) {

                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);

                ArrayList<QrDataInformation> qritems = response.body().getResults();

                Gson gson = new Gson();
                String valuesString = gson.toJson(qritems);
                System.out.println(valuesString);

                Log.d("checkrepsonsem", "" + valuesString);

                for (int i = 0; i < qritems.size(); i++) {

                    Data1 = qritems.get(i).getBalance_Amount();

                    Data2 = qritems.get(i).getLorrshed_status();

                    Data3 = qritems.get(i).getDelivered_sign();

                    Data4 = qritems.get(i).getDriver_status();

                    Data5 = qritems.get(i).getBill_no();

                    Log.d("checkrepsonsem", "" + Data1);

                    Log.d("checkrepsonsem", "" + Data2);

                    Log.d("checkrepsonsem", "" + Data3);

                    Log.d("checkrepsonsem", "" + Data4);

                    String Stst = "indriver";

                    //  Datadt = sdfs.format( new Date() );

                    if (Data1 == null) {

                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();

                        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText("Warning !..")
                                .setContentText("No Record Found : Balance Amount Not Found")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(sDialog -> {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                })
                                .show();

                    } else if (Data4 == null) {
                        Data4 = "incompany";
                        if (Data4.equals(Stst)) {
                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                    .setTitleText("Warning !..")
                                    .setContentText("The Bill Status Already In : 'InDriver'")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(sDialog -> {
                                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                        finish();
                                        sDialog.cancel();
                                    })
                                    .show();

                        } else if (Data2.equals("pending")) {
                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();
                            tv_heading.setText("Scan For Driver Bill Taken");
                            tv_balance_amount_val.setText("" + Data1);
                            tv_current_status_val.setText("" + Data4);
                            tv_changing_status_val.setText("InDriver");
                            tv_selected_date_val.setText("" + qr_data_date);
                            tv_Seelected_Driver_val.setText("" + qr_data_drname);
                            tv_bill_no_val.setText("" + Data5);

                            tv_Seelected_Driver_val.setOnClickListener(view -> popitem());


                            Log.d("Datadt", "" + Datadt);

                            tv_selected_date_val.setOnClickListener(view -> new DatePickerDialog(MainActivity.this, date, myCalendar
                                    .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                    myCalendar.get(Calendar.DAY_OF_MONTH)).show());

                            btn_back_to_qr_scan.setOnClickListener(view -> {
                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                finish();
                            });

                            btn_submit_status.setOnClickListener(view -> {
                                progressDialog = new ProgressDialog(MainActivity.this);
                                progressDialog.setMessage("Loading..."); // Setting Message
                                progressDialog.setTitle("Status"); // Setting Title
                                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                progressDialog.show(); // Display Progress Dialog
                                String Status = "InDriver";
                                DriverInfoDetails Qr = new DriverInfoDetails();
                                Log.d("M", "" + qr_data);
                                Log.d("Ma", "" + Status);
                                Log.d("Man", "" + qr_data_date);

                                makeNotification(0, "" + qr_data + " - " + Status, MainActivity.this, "Qr Code Status Generated", com.prime.admin.sakthi.activity.MainActivity.class);

                                ApiClient.getClientUpdate(parts[1], baseUrl).setDriverBillTaken(qr_data, Status, qr_data_date, qr_data_drid).enqueue(new Qr());

                            });

                        } else if (Data3.equals("pending")) {
                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();
                            tv_heading.setText("Scan For Driver Bill Taken");
                            tv_balance_amount_val.setText("" + Data1);
                            tv_current_status_val.setText("" + Data4);
                            tv_changing_status_val.setText("InDriver");
                            tv_selected_date_val.setText("" + qr_data_date);
                            tv_Seelected_Driver_val.setText("" + qr_data_drname);
                            tv_bill_no_val.setText("" + Data5);

                            tv_Seelected_Driver_val.setOnClickListener(view -> popitem());


                            Log.d("Datadt", "" + Datadt);

                            tv_selected_date_val.setOnClickListener(view -> new DatePickerDialog(MainActivity.this, date, myCalendar
                                    .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                    myCalendar.get(Calendar.DAY_OF_MONTH)).show());

                            btn_back_to_qr_scan.setOnClickListener(view -> {
                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                finish();
                            });

                            btn_submit_status.setOnClickListener(view -> {
                                progressDialog = new ProgressDialog(MainActivity.this);
                                progressDialog.setMessage("Loading..."); // Setting Message
                                progressDialog.setTitle("Status"); // Setting Title
                                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                progressDialog.show(); // Display Progress Dialog
                                String Status = "InDriver";
                                DriverInfoDetails Qr = new DriverInfoDetails();
                                Log.d("M", "" + qr_data);
                                Log.d("Ma", "" + Status);
                                Log.d("Man", "" + qr_data_date);

                                makeNotification(0, "" + qr_data + " - " + Status, MainActivity.this, "Qr Code Status Generated", MainActivity.class);

                                ApiClient.getClientUpdate(parts[1], baseUrl).setDriverBillTaken(qr_data, Status, qr_data_date, qr_data_drid).enqueue(new Qr());

                            });

                        } else {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                    .setTitleText("Warning !..")
                                    .setContentText("This Bill Is Already Cancelled / Delivered !")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(sDialog -> {
                                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                        finish();
                                        sDialog.cancel();
                                    })
                                    .show();
                        }
                    } else if (Data4.equals(Stst)) {

                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();

                        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText("Warning !..")
                                .setContentText("The Bill Status Already In : 'InDriver'")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(sDialog -> {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    finish();
                                    sDialog.cancel();
                                })
                                .show();

                    } else if (Data2.equals("pending")) {

                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();
                        tv_heading.setText("Scan For Driver Bill Taken");
                        tv_balance_amount_val.setText("" + Data1);
                        tv_current_status_val.setText("" + Data4);
                        tv_changing_status_val.setText("InDriver");
                        tv_selected_date_val.setText("" + qr_data_date);
                        tv_Seelected_Driver_val.setText("" + qr_data_drname);
                        tv_bill_no_val.setText("" + Data5);

                        tv_Seelected_Driver_val.setOnClickListener(view -> popitem());

                        Log.d("Datadt", "" + qr_data_date);

                        tv_selected_date_val.setOnClickListener(view -> new DatePickerDialog(MainActivity.this, date, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show());

                        btn_back_to_qr_scan.setOnClickListener(view -> {
                            startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                            finish();
                        });

                        btn_submit_status.setOnClickListener(view -> {
                            progressDialog = new ProgressDialog(MainActivity.this);
                            progressDialog.setMessage("Loading..."); // Setting Message
                            progressDialog.setTitle("Status"); // Setting Title
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                            progressDialog.show(); // Display Progress Dialog
                            String Status = "InDriver";
                            DriverInfoDetails Qr = new DriverInfoDetails();
                            Log.d("M", "" + qr_data);
                            Log.d("Ma", "" + Status);
                            Log.d("Man", "" + qr_data_date);

                            makeNotification(0, "" + qr_data + " - " + Status, MainActivity.this, "Qr Code Status Generated", MainActivity.class);

                            ApiClient.getClientUpdate(parts[1], baseUrl).setDriverBillTaken(qr_data, Status, qr_data_date, qr_data_drid).enqueue(new Qr());

                        });

                    } else if (Data3.equals("pending")) {

                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();
                        tv_heading.setText("Scan For Driver Bill Taken");
                        tv_balance_amount_val.setText("" + Data1);
                        tv_current_status_val.setText("" + Data4);
                        tv_changing_status_val.setText("InDriver");
                        tv_selected_date_val.setText("" + qr_data_date);
                        tv_Seelected_Driver_val.setText("" + qr_data_drname);
                        tv_bill_no_val.setText("" + Data5);

                        tv_Seelected_Driver_val.setOnClickListener(view -> popitem());

                        Log.d("Datadt", "" + qr_data_date);

                        tv_selected_date_val.setOnClickListener(view -> new DatePickerDialog(MainActivity.this, date, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show());

                        btn_back_to_qr_scan.setOnClickListener(view -> {
                            startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                            finish();
                        });

                        btn_submit_status.setOnClickListener(view -> {
                            progressDialog = new ProgressDialog(MainActivity.this);
                            progressDialog.setMessage("Loading..."); // Setting Message
                            progressDialog.setTitle("Status"); // Setting Title
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                            progressDialog.show(); // Display Progress Dialog
                            String Status = "InDriver";
                            DriverInfoDetails Qr = new DriverInfoDetails();
                            Log.d("M", "" + qr_data);
                            Log.d("Ma", "" + Status);
                            Log.d("Man", "" + qr_data_date);

                            makeNotification(0, "" + qr_data + " - " + Status, MainActivity.this, "Qr Code Status Generated", MainActivity.class);

                            ApiClient.getClientUpdate(parts[1], baseUrl).setDriverBillTaken(qr_data, Status, qr_data_date, qr_data_drid).enqueue(new Qr());

                        });

                    } else {
                        progressDialog.setCancelable(false);
                        progressDialog.dismiss();
                        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText("Warning !..")
                                .setContentText("This Bill Is Already Cancelled / Delivered !")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(sDialog -> {
                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                    MainActivity.this.finish();
                                    sDialog.cancel();
                                })
                                .show();
                    }
                }
            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        })
                        .show();
            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                            MainActivity.this.finish();
                            sDialog.cancel();
                        })
                        .show();
            }
        }

        @Override
        public void onFailure(Call<QrDataInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class ShowItemList implements Callback<DriverInfoResponse> {

        ShowItemList() {

        }

        public void onResponse(Call<DriverInfoResponse> call, Response<DriverInfoResponse> response) {
            if (response.isSuccessful()) {
                int success = response.body().getSuccess();
                if (success == 1) {
                    items = response.body().getResults();
                    Gson gson = new Gson();
                    String valuesString = gson.toJson(items);
                    System.out.println(valuesString);
//                session.setItems(valuesString);
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    final Dialog dialog = new Dialog(MainActivity.this);
                    dialog.setContentView(R.layout.fragment_item_list);
                    search = dialog.findViewById(R.id.search);
                    rv = dialog.findViewById(R.id.card_recycler_view_item_list);
                    rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    iadapter = new DialogDriverListAdapter(getApplicationContext(), items);
                    rv.setAdapter(iadapter);
                    dialog.show();

                    Toolbar toolbar2 = dialog.findViewById(R.id.toolbar4);
                    setSupportActionBar(toolbar2);
                    toolbar2.setTitle("Driver List");

                    search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                        @Override
                        public boolean onQueryTextSubmit(String newText) {
                            return false;
                        }

                        @Override
                        public boolean onQueryTextChange(String query) {
                            Log.i("well", " this worked");
                            iadapter.getFilter().filter(query);
                            return false;
                        }
                    });

                    rv.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rv, new RecyclerTouchListener.ClickListener() {
                        @Override
                        public void onClick(View view, int position) {
                            itemInfo = items.get(position);

                            qr_data_drid = String.valueOf(itemInfo.getDriver_id());
                            Log.d("Driver", "" + qr_data_drid);

                            qr_data_drname = itemInfo.getDriver_name();
                            Log.d("Driver", "" + qr_data_drname);

                            dialog.dismiss();

                            tv_Seelected_Driver_val.setText("" + qr_data_drname);

                        }

                        @Override
                        public void onLongClick(View view, int position) {

                        }
                    }));

                    Log.d("jjj", "Number of items received: " + items.size());
                } else if (success == 0) {
                    String message = response.body().getMessage();

                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();
                } else if (success == 2) {
                    String message = response.body().getMessage();

                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })

                            .show();
                } else {

                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();
                }
            }
        }

        public void onFailure(Call<DriverInfoResponse> call, Throwable t) {

        }
    }


    class Qr implements Callback<DriverBillTakenDetails> {

        Qr() {

        }

        @Override
        public void onResponse(Call<DriverBillTakenDetails> call, Response<DriverBillTakenDetails> response) {
            if (response.isSuccessful()) {
                System.out.println("Entering");
                int success = response.body().getSuccess();
                String messsge = response.body().getMessage();
                System.out.println("Success" + success);
                Log.d("checkrepsonse", "" + success + "\t" + response);
                if (success == 1) {
                    String message = response.body().getMessage();
                    Log.d("progressDialog", "" + message);
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    Toast.makeText(MainActivity.this, "Status Submitted",
                            Toast.LENGTH_LONG).show();

                    Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                    i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i1);


                } else if (success == 0) {
                    String message = response.body().getMessage();
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setContentText("The Bill Status Already In : 'InDriver'")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();

                } else {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setContentText("The Bill Status Already In : 'InDriver'")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();
                }
            }
        }


        @Override
        public void onFailure(Call<DriverBillTakenDetails> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }
}
