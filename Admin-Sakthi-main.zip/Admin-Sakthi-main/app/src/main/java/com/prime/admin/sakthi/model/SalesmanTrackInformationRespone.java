package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Admin on 11/24/2016.
 */

public class SalesmanTrackInformationRespone {

    @SerializedName("map")
    private ArrayList<SalesmanTrackInformation> results;
    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public int getSuccess() {
        return this.success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public ArrayList<SalesmanTrackInformation> getResults() {
        return this.results;
    }

    public void setResults(ArrayList<SalesmanTrackInformation> results) {
        this.results = results;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
