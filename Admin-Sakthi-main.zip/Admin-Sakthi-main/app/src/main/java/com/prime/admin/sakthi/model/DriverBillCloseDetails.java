package com.prime.admin.sakthi.model;

/**
 * Created by Admin on 11/16/2016.
 */

import com.google.gson.annotations.SerializedName;

public class DriverBillCloseDetails {

    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
