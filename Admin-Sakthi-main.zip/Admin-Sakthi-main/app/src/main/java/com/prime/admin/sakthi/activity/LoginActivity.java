package com.prime.admin.sakthi.activity;

import static com.prime.admin.sakthi.util.Utils.makeNotification;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.collection.ArrayMap;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.prime.admin.sakthi.BuildConfig;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.model.UserInformation;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.util.Utils;

import java.math.BigInteger;
import java.net.UnknownHostException;
import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    Button button;
    EditText Mailid, Password;
    CheckBox cbSaveDetails;
    TextView txtVersion;

    SharedPreferences userid, username, phonenumber, phonenumberopt, aadharr, emailid, addresss, types;
    String messsage, name = "", type = "", email = "", address = "";
    ProgressDialog progressDialog;
    int id;
    BigInteger phone, phoneopt, aadhar;

    ImageView settings;

    private static boolean isValidEmail(String phone) {
        return !TextUtils.isEmpty(phone) && Patterns.PHONE.matcher(phone).matches();
    }

    public static boolean checkPassword(String password) {
        return "admin".equals(password);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtVersion = (TextView) findViewById(R.id.version);
        settings = findViewById(R.id.image_settings);

        try {
            txtVersion.setText(BuildConfig.VERSION_NAME);

        } catch (Exception exp) {

        }

        this.overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

        final ArrayList<String> data = new ArrayList<>();

        ArrayMap<String, String> deviceDataMap = new ArrayMap<>();

        for (String key : deviceDataMap.keySet()) {
            data.add(key + " : " + deviceDataMap.get(key));
        }

        String fontPath = "BankGothic Bold.ttf";
        TextView aboutus = (TextView) findViewById(R.id.textView6);
        Typeface type = Typeface.createFromAsset(getAssets(), fontPath);
        aboutus.setTypeface(type);

        Log.d("Manikandan", "" + Common.PhoneIMEI);

        userid = LoginActivity.this.getSharedPreferences("MyPref", 0);
        username = LoginActivity.this.getSharedPreferences("MyPref", 0);
        phonenumber = LoginActivity.this.getSharedPreferences("MyPref", 0);
        phonenumberopt = LoginActivity.this.getSharedPreferences("MyPref", 0);
        aadharr = LoginActivity.this.getSharedPreferences("MyPref", 0);
        emailid = LoginActivity.this.getSharedPreferences("MyPref", 0);
        addresss = LoginActivity.this.getSharedPreferences("MyPref", 0);
        types = LoginActivity.this.getSharedPreferences("MyPref", 0);

        Password = (EditText) findViewById(R.id.edittext_password);
        Mailid = (EditText) findViewById(R.id.edittext_mail);
        button = (Button) findViewById(R.id.btn_login);

        if (Common.LoginCacheCheck == null) {
            System.out.println("Login Check");
        } else if (Common.LoginCacheCheck.equals("")) {
            System.out.println("Login Check");
        } else if (Common.LoginCacheCheck.isEmpty()) {
            System.out.println("Login Check");
        } else if (Common.LoginCacheCheck.equals("AdminApp")) {
            Mailid.setText("");
            Password.setText("");
            cbSaveDetails.setChecked(false);
        } else {
            System.out.println("Login Check");
        }

        cbSaveDetails = (CheckBox) findViewById(R.id.cbSaveDetails);
        if (loadPreferences("isSaveChecked").equalsIgnoreCase("True")) {
            cbSaveDetails.setChecked(true);
            Mailid.setText(loadPreferences("email"));
            Password.setText(loadPreferences("Password"));
        } else {
            savePreferences("email", "");
            savePreferences("Password", "");
            Mailid.setText("");
            Password.setText("");
        }

        button.setOnClickListener(v -> {
            button.setVisibility(View.GONE);

            progressDialog = new ProgressDialog(LoginActivity.this);
            progressDialog.setMessage("Loading..."); // Setting Message
            progressDialog.setTitle("Login"); // Setting Title
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
            progressDialog.show(); // Display Progress Dialog

            next();

        });

        settings.setOnClickListener(view -> passwordDialog());

    }

    private boolean validatePassword() {
        if (this.Password.getText().toString().trim().isEmpty()) {
            progressDialog.setCancelable(false);
            progressDialog.dismiss();
            new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.WARNING_TYPE)
                    .setContentText("Please Enter Valid Password")
                    .setConfirmText("Ok")
                    .setConfirmClickListener(sDialog -> sDialog.cancel())
                    .show();
            requestFocus(this.Password);
            return false;
        }
        return true;
    }

    private boolean validateEmail() {
        String phone = Mailid.getText().toString().trim();
        if (phone.isEmpty() || !isValidEmail(phone)) {
            progressDialog.setCancelable(false);
            progressDialog.dismiss();
            new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.WARNING_TYPE)
                    .setContentText("Please Enter Valid Phone Number")
                    .setConfirmText("Ok")
                    .setConfirmClickListener(sDialog -> sDialog.cancel())
                    .show();
            requestFocus(this.Mailid);
            return false;
        }
        return true;
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(5);
        }
    }

    private void next() {
        if (validateEmail() && validatePassword()) {
            String baseUrl = Utils.getBaseUrl(LoginActivity.this);
            ApiClient.getClient(baseUrl).getUserInfo(this.Mailid.getText().toString().trim(), this.Password.getText().toString().trim()).enqueue(new Login());
        }
    }

    public void savePreferences(String key, String value) {
        SharedPreferences sharedPreferences = getPreferences();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public SharedPreferences getPreferences() {
        return this.getSharedPreferences("salesapp", Context.MODE_PRIVATE);
    }

    public String loadPreferences(String key) {
        try {
            SharedPreferences sharedPreferences = getPreferences();
            return sharedPreferences.getString(key, "");
        } catch (NullPointerException nullPointerException) {
            return null;
        }
    }

    public void onStart() {
        super.onStart();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }

    private void passwordDialog() {
        final Dialog mDialog = new Dialog(this);

        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(R.layout.password_dialog);
        mDialog.setCancelable(true);

        if (mDialog.getWindow() != null) {
            mDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mDialog.getWindow().setLayout(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
            );
        }

        LinearLayout view = mDialog.findViewById(R.id.mMessageLay);
        MaterialButton cancel = mDialog.findViewById(R.id.cancel);
        MaterialButton ok = mDialog.findViewById(R.id.ok);
        TextInputEditText password = mDialog.findViewById(R.id.dialog_password);

        cancel.setOnClickListener(v -> mDialog.dismiss());

        ok.setOnClickListener(v -> {
            if (checkPassword(password.getText().toString())) {
                mDialog.dismiss();
                urlChangeDialog();
            } else {
                Snackbar.make(view, "Password is wrong", Snackbar.LENGTH_LONG).show();
            }
        });

        mDialog.show();
    }

    private void urlChangeDialog() {
        final Dialog mDialog = new Dialog(this);

        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(R.layout.change_url_dialog);
        mDialog.setCancelable(true);

        if (mDialog.getWindow() != null) {
            mDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mDialog.getWindow().setLayout(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
            );
        }

        LinearLayout view = mDialog.findViewById(R.id.mMessageLay);
        MaterialButton cancel = mDialog.findViewById(R.id.cancel);
        MaterialButton ok = mDialog.findViewById(R.id.ok);
        TextInputEditText url = mDialog.findViewById(R.id.dialog_url);
        String baseURL = Utils.getBaseUrl(this);
        url.setText(baseURL);

        cancel.setOnClickListener(v -> mDialog.dismiss());

        ok.setOnClickListener(v -> {
            if (!url.getText().toString().isEmpty()) {
                char lastChar = url.getText().toString().charAt(url.getText().toString().length() - 1);
                if (lastChar != '/') {
                    Snackbar.make(view, "Url should end with /", Snackbar.LENGTH_LONG).show();
                } else {
                    Utils.setBaseUrl(LoginActivity.this, url.getText().toString());
                    mDialog.dismiss();
                }
            } else {
                Snackbar.make(view, "Url is empty", Snackbar.LENGTH_LONG).show();
            }
        });

        mDialog.show();
    }


    class Login implements Callback<UserInformation> {

        Login() {

        }

        public void onResponse(Call<UserInformation> call, Response<UserInformation> response) {
            if (response.isSuccessful()) {
                System.out.println("Entering");
                int success = ((UserInformation) response.body()).getSuccess();
                System.out.println("Success" + success);
                Log.d("Success", "" + success);
                if (success == 1) {
                    id = ((UserInformation) response.body()).getUserID();
                    name = ((UserInformation) response.body()).getUserName();
                    type = ((UserInformation) response.body()).getUserType();
                    email = ((UserInformation) response.body()).getUserEmail();
                    address = ((UserInformation) response.body()).getUserAddress();
                    phone = ((UserInformation) response.body()).getUserPhone();
                    phoneopt = ((UserInformation) response.body()).getUserPhoneOpt();
                    aadhar = ((UserInformation) response.body()).getUserAadhar();
                    System.out.println("EmailID" + email);
                    messsage = ((UserInformation) response.body()).getMessage();

                    userid.edit().putString("userid", String.valueOf(id)).apply();
                    username.edit().putString("username", String.valueOf(name)).apply();
                    phonenumber.edit().putString("phone", String.valueOf(phone)).apply();
                    phonenumberopt.edit().putString("phoneopt", String.valueOf(phoneopt)).apply();
                    aadharr.edit().putString("aadhar", String.valueOf(aadhar)).apply();
                    emailid.edit().putString("emailid", String.valueOf(email)).apply();
                    addresss.edit().putString("address", String.valueOf(address)).apply();
                    types.edit().putString("type", String.valueOf(type)).apply();

                    if (cbSaveDetails.isChecked()) {
                        savePreferences("isSaveChecked", "True");
                        savePreferences("email", Mailid.getText().toString());
                        savePreferences("Password", Password.getText().toString());
                    } else {
                        savePreferences("isSaveChecked", "False");
                        savePreferences("email", "");
                        savePreferences("Password", "");
                    }
                    makeNotification(0, "" + type + " - " + name, LoginActivity.this, "Login Successful", MainActivity.class);


                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();

                    if (type.equalsIgnoreCase("admin")) {

                        new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("" + messsage)
                                .setConfirmText("Ok")
                                .setConfirmClickListener(sDialog -> {
                                    Intent i = new Intent(LoginActivity.this, MainActivity.class);
                                    i.putExtra("username", name);
                                    startActivity(i);
                                    LoginActivity.this.finish();
                                    sDialog.cancel();
                                })
                                .show();

                    } else if (type.equalsIgnoreCase("salesman")) {

                        new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.WARNING_TYPE)
                                .setContentText("Warning !")
                                .setContentText("You Are Not Authorised User")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(sDialog -> {
                                    button.setVisibility(View.VISIBLE);
                                    sDialog.cancel();
                                })
                                .show();

                    } else if (type.equalsIgnoreCase("driver")) {

                        new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.WARNING_TYPE)
                                .setContentText("Warning !")
                                .setContentText("You Are Not Authorised User")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(sDialog -> {
                                    button.setVisibility(View.VISIBLE);
                                    sDialog.cancel();
                                })
                                .show();
                    }

                } else if (success == 0) {
                    String message = response.body().getMessage();
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setContentText("" + message)
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                button.setVisibility(View.VISIBLE);
                                sDialog.cancel();
                            })
                            .show();
                } else if (success == 2) {
                    String message = response.body().getMessage();
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("" + message)
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                button.setVisibility(View.VISIBLE);
                                sDialog.cancel();
                            })

                            .show();
                } else {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Error")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                button.setVisibility(View.VISIBLE);
                                sDialog.cancel();
                            })
                            .show();
                }
            }
        }

        @Override
        public void onFailure(Call<UserInformation> call, Throwable t) {
            if (t instanceof UnknownHostException) {
                button.setVisibility(View.VISIBLE);
                progressDialog.dismiss();
                progressDialog.cancel();
                new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.ERROR_TYPE)
                        .setContentText("Warning !")
                        .setContentText("Kindly Check your Internet Connection")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            button.setVisibility(View.VISIBLE);
                            sDialog.cancel();
                        })
                        .show();
            } else {
                button.setVisibility(View.VISIBLE);
                progressDialog.dismiss();
                progressDialog.cancel();
                new SweetAlertDialog(LoginActivity.this, SweetAlertDialog.ERROR_TYPE)
                        .setContentText("Warning !")
                        .setContentText(t.getMessage())
                        .setConfirmText("Ok")
                        .setConfirmClickListener(sDialog -> {
                            button.setVisibility(View.VISIBLE);
                            sDialog.cancel();
                        })
                        .show();
            }

        }
    }

}
