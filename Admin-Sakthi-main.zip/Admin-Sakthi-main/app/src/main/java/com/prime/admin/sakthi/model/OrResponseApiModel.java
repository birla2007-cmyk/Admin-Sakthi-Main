package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by hakiki95 on 4/26/2017.
 */

public class OrResponseApiModel {

    @SerializedName("count")
    private ArrayList<OrResponseApiModel> results;

    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public ArrayList<OrResponseApiModel> getResults() {
        return this.results;
    }

    public void setResults(ArrayList<OrResponseApiModel> results) {
        this.results = results;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
