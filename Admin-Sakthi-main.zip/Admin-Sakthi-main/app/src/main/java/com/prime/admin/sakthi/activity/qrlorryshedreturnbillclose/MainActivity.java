package com.prime.admin.sakthi.activity.qrlorryshedreturnbillclose;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.RecyclerTouchListener;
import com.prime.admin.sakthi.adapter.DialogDriverListAdapter;
import com.prime.admin.sakthi.model.DriverBillCloseDetails;
import com.prime.admin.sakthi.model.DriverBillCloseWithNoImgInformationRespone;
import com.prime.admin.sakthi.model.DriverInfoDetails;
import com.prime.admin.sakthi.model.DriverInfoResponse;
import com.prime.admin.sakthi.model.QrDataInformation;
import com.prime.admin.sakthi.model.QrDataInformationRespone;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.io.File;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity QR";
    final int REQUEST_GALLERY = 9544;
    private final int requestCode = 20;
    String DataQr, Data1, Data2, Data3, Data4, Data5, Datadt, class_check = "", qr_data = "", qr_datas = "", checkImages, part_image;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    SearchView search;
    RecyclerView rv;
    DialogDriverListAdapter iadapter;
    ArrayList<DriverInfoDetails> items;
    DriverInfoDetails itemInfo;
    String DriverID = "", DriverName = "";
    ProgressDialog progressDialog;
    SharedPreferences dates, status, qrdata, qrcomdate;
    OutputStream ops = null;
    ObjectOutputStream objOps = null;
    TextView tv_balance_amount_val, tv_current_status_val, tv_bill_no_val, tv_selected_date_val, tv_selected_date, tv_changing_status_val, tv_heading, tv_yes, tv_no, tv_Seelected_Driver_val;
    Button btn_back_to_qr_scan, btn_submit_status, btn_Add_Image, btn_Remove_Image, LoadImage;
    ImageView Image;
    CardView card_view, card_view1;
    LinearLayout ll2, heading_layout1, btn, btnL, btnLL;
    String YesNo = "", Stat = "";
    SimpleDateFormat sdfs;
    SharedPreferences Images;
    String[] parts = new String[0];
    String baseUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultdlsrbc);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        baseUrl =Utils.getBaseUrl(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        tv_balance_amount_val = findViewById(R.id.tv_balance_amount_val);
        tv_current_status_val = findViewById(R.id.tv_current_status_val);
        tv_selected_date_val = findViewById(R.id.tv_selected_date_val);
        tv_selected_date = findViewById(R.id.tv_selected_date);
        tv_changing_status_val = findViewById(R.id.tv_changing_status_val);
        tv_heading = findViewById(R.id.tv_heading);
        tv_bill_no_val = findViewById(R.id.tv_bill_no_val);
        btn_back_to_qr_scan = findViewById(R.id.btn_back_to_qr_scan);
        btn_submit_status = findViewById(R.id.btn_submit_status);

        card_view = findViewById(R.id.card_view);
        Image = findViewById(R.id.Image);

        btn = findViewById(R.id.btn);
        btnL = findViewById(R.id.btnL);

        if (getIntent() != null) {
            class_check = getIntent().getStringExtra("qr");

            if (class_check.equalsIgnoreCase("1")) {
                qr_data = getIntent().getStringExtra("qr_data");
                parts = qr_data.split("-");
                qr_data = parts[0];
                DataQr = parts[0];
            }
        }

        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Scan For Driver Driver Lorry Shed Return Bill Close"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog

        ApiClient.getClientUpdate(parts[1], baseUrl).setQrDataInfo(qr_data).enqueue(new MainActivity.Receipt());


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "" + requestCode + "\t" + resultCode + "\t" + data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_GALLERY) {
                Uri dataimage = data.getData();
                String[] imageprojection = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(dataimage, imageprojection, null, null, null);

                if (cursor != null) {
                    cursor.moveToFirst();
                    int indexImage = cursor.getColumnIndex(imageprojection[0]);
                    part_image = cursor.getString(indexImage);

                    if (part_image != null) {
                        File image = new File(part_image);
                        Image.setImageBitmap(BitmapFactory.decodeFile(image.getAbsolutePath()));
                    }
                }
            }
        }
    }

    public void popitem() {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Show Driver List"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        ApiClient.getClient(baseUrl).getDriverInfo().enqueue(new MainActivity.ShowItemList());
    }

    class Receipt implements Callback<QrDataInformationRespone> {

        Receipt() {

        }

        @Override
        public void onResponse(Call<QrDataInformationRespone> call, Response<QrDataInformationRespone> response) {
            if (response.isSuccessful()) {
                System.out.println("Entering");
                int success = response.body().getSuccess();
                String messsge = response.body().getMessage();
                System.out.println("Success" + success);
                Log.d("checkrepsonsem", "" + success + "\t" + response);
                if (success == 1) {

                    String message = response.body().getMessage();
                    Log.d("progressDialog", "" + message);

                    ArrayList<QrDataInformation> qritems = response.body().getResults();

                    Gson gson = new Gson();
                    String valuesString = gson.toJson(qritems);
                    System.out.println(valuesString);

                    Log.d("checkrepsonsem", "" + valuesString);

                    Stat = "InCompany";

                    for (int i = 0; i < qritems.size(); i++) {

                        Data1 = qritems.get(i).getBalance_Amount();

                        Data2 = qritems.get(i).getDelivery_type();

                        Data3 = qritems.get(i).getLorrshed_status();

                        Data4 = qritems.get(i).getDriver_status();

                        Data5 = qritems.get(i).getBill_no();

                        Log.d("checkrepsonsem", "" + Data1);
                        Log.d("checkrepsonsem", "" + Data2);
                        Log.d("checkrepsonsem", "" + Data3);
                        Log.d("checkrepsonsem", "" + Data4);


                        if (Data1 == null && Data3 == null && Data4 == null) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            btn_submit_status.setVisibility(View.GONE);
                            card_view.setVisibility(View.GONE);

                            Image.setImageResource(R.drawable.closebutton);

                            btn_back_to_qr_scan.setOnClickListener(view -> {

                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                MainActivity.this.finish();

                            });

                        } else if (Data1.isEmpty() && Data3.isEmpty() && Data4.isEmpty()) {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            btn_submit_status.setVisibility(View.GONE);
                            card_view.setVisibility(View.GONE);

                            Image.setImageResource(R.drawable.closebutton);

                            btn_back_to_qr_scan.setOnClickListener(view -> {

                                startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                MainActivity.this.finish();

                            });

                        } else if (Data2.equals("lorry shed")) {

                            if (!Data3.equals("cancel")) {

                                if (Data3.equals("sent to lorryshed")) {

                                    if (Data4.equals("incompany")) {

                                        progressDialog.setCancelable(false);
                                        progressDialog.dismiss();

                                        Image.setVisibility(View.GONE);

                                        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                                .setTitleText("Bill Already Scanned")
                                                .setConfirmText("Ok")
                                                .setConfirmClickListener(sDialog -> {
                                                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                                    MainActivity.this.finish();
                                                    sDialog.cancel();
                                                })
                                                .show();

                                    } else if (Data4.equals("indriver")) {

                                        progressDialog.setCancelable(false);
                                        progressDialog.dismiss();

                                        Image.setVisibility(View.GONE);

                                        tv_heading.setText("LorryShed Return Bill Close");
                                        tv_balance_amount_val.setText("" + Data1);
                                        tv_current_status_val.setText("InDriver");
                                        tv_changing_status_val.setText("InCompany");
                                        tv_bill_no_val.setText("" + Data5);

                                        btn_back_to_qr_scan.setOnClickListener(view -> {

                                            startActivity(new Intent(MainActivity.this, DecoderActivity.class));
                                            MainActivity.this.finish();

                                        });

                                        btn_submit_status.setOnClickListener(view -> {

                                            progressDialog.setCancelable(false);
                                            progressDialog.dismiss();

                                            progressDialog = new ProgressDialog(MainActivity.this);
                                            progressDialog.setMessage("Loading..."); // Setting Message
                                            progressDialog.setTitle("Status Submit"); // Setting Title
                                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                            progressDialog.show(); // Display Progress Dialog

                                            ApiClient.getClientUpdate(parts[1], baseUrl).setDeliveredBillCloseNoImg(qr_data, Stat).enqueue(new QrDrReceipt());

                                        });

                                    }

                                } else if (Data3.equals("delivered")) {

                                    progressDialog.setCancelable(false);
                                    progressDialog.dismiss();

                                    Image.setVisibility(View.GONE);

                                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                            .setTitleText("Delivered Bill")
                                            .setConfirmText("Ok")
                                            .setConfirmClickListener(sDialog -> {
                                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                                MainActivity.this.finish();
                                                sDialog.cancel();
                                            })
                                            .show();

                                }
                            } else {
                                progressDialog.setCancelable(false);
                                progressDialog.dismiss();

                                Image.setVisibility(View.GONE);

                                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                        .setTitleText("Cancelled Bill")
                                        .setConfirmText("Ok")
                                        .setConfirmClickListener(sDialog -> {
                                            startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                            MainActivity.this.finish();
                                            sDialog.cancel();
                                        })
                                        .show();
                            }

                        } else {

                            progressDialog.setCancelable(false);
                            progressDialog.dismiss();

                            Image.setVisibility(View.GONE);

                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                    .setTitleText("Direct Bill")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(sDialog -> {
                                        startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                        MainActivity.this.finish();
                                        sDialog.cancel();
                                    })
                                    .show();
                        }

                        //close
                    }


                } else if (success == 0) {
                    String message = response.body().getMessage();
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();
                } else {
                    progressDialog.setCancelable(false);
                    progressDialog.dismiss();
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("No Record Found")
                            .setConfirmText("Ok")
                            .setConfirmClickListener(sDialog -> {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            })
                            .show();
                }
            }
        }

        @Override
        public void onFailure(Call<QrDataInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class QrDrReceipt implements Callback<DriverBillCloseWithNoImgInformationRespone> {

        QrDrReceipt() {

        }

        @Override
        public void onResponse(Call<DriverBillCloseWithNoImgInformationRespone> call, Response<DriverBillCloseWithNoImgInformationRespone> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonses", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(MainActivity.this, "Status Submitted",
                        Toast.LENGTH_LONG).show();

                Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);

            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InCompany'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();


            }
        }

        @Override
        public void onFailure(Call<DriverBillCloseWithNoImgInformationRespone> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }

    class ShowItemList implements Callback<DriverInfoResponse> {

        ShowItemList() {

        }

        public void onResponse(Call<DriverInfoResponse> call, Response<DriverInfoResponse> response) {
            int success = response.body().getSuccess();
            if (success == 1) {
                items = response.body().getResults();
                Gson gson = new Gson();
                String valuesString = gson.toJson(items);
                System.out.println(valuesString);
//                session.setItems(valuesString);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.fragment_item_list);
                search = dialog.findViewById(R.id.search);
                rv = dialog.findViewById(R.id.card_recycler_view_item_list);
                rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                iadapter = new DialogDriverListAdapter(getApplicationContext(), items);
                rv.setAdapter(iadapter);
                dialog.show();

                Toolbar toolbar2 = dialog.findViewById(R.id.toolbar4);
                setSupportActionBar(toolbar2);
                toolbar2.setTitle("Driver List");

                search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String newText) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String query) {
                        Log.i("well", " this worked");
                        iadapter.getFilter().filter(query);
                        return false;
                    }
                });

                rv.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rv, new RecyclerTouchListener.ClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        itemInfo = items.get(position);

                        DriverID = String.valueOf(itemInfo.getDriver_id());
                        Log.d("Driver", "" + DriverID);

                        DriverName = itemInfo.getDriver_name();
                        Log.d("Driver", "" + DriverName);

                        dialog.dismiss();

                        // tv_Seelected_Driver_val.setText(""+DriverName);

                    }

                    @Override
                    public void onLongClick(View view, int position) {

                    }
                }));

                Log.d("jjj", "Number of items received: " + items.size());
            } else if (success == 0) {
                String message = response.body().getMessage();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();
            } else if (success == 2) {
                String message = response.body().getMessage();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })

                        .show();
            } else {

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();
            }
        }

        public void onFailure(Call<DriverInfoResponse> call, Throwable t) {

        }
    }

    class Qr implements Callback<DriverBillCloseDetails> {

        Qr() {

        }

        @Override
        public void onResponse(Call<DriverBillCloseDetails> call, Response<DriverBillCloseDetails> response) {
            System.out.println("Entering");
            int success = response.body().getSuccess();
            String messsge = response.body().getMessage();
            System.out.println("Success" + success);
            Log.d("checkrepsonse", "" + success + "\t" + response);
            if (success == 1) {
                String message = response.body().getMessage();
                Log.d("progressDialog", "" + message);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                Toast.makeText(MainActivity.this, "Status Submitted",
                        Toast.LENGTH_LONG).show();

                Intent i1 = new Intent(MainActivity.this, DecoderActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);


            } else if (success == 0) {
                String message = response.body().getMessage();
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InDriver'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();

            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setContentText("The Bill Status Already In : 'InDriver'")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.MainActivity.class));
                                MainActivity.this.finish();
                                sDialog.cancel();
                            }
                        })
                        .show();


            }
        }


        @Override
        public void onFailure(Call<DriverBillCloseDetails> call, Throwable t) {
            Log.d(TAG, "yyu" + "\t" + t.toString());
        }
    }
}
