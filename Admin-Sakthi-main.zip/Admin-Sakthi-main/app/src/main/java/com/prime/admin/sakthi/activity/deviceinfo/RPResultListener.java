package com.prime.admin.sakthi.activity.deviceinfo;

interface RPResultListener {
    void onPermissionGranted();

    void onPermissionDenied();
}
