package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Admin on 11/18/2016.
 */

public class UserInformationResponse {
    @SerializedName("user")
    private UserInformation tag;
    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public int getSuccess() {
        return this.success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UserInformation getUser() {
        return this.tag;
    }

    public void setUser(UserInformation tag) {
        this.tag = tag;
    }
}
