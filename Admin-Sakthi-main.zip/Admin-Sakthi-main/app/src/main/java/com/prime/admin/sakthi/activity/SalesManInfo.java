package com.prime.admin.sakthi.activity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.util.SessionManager;

public class SalesManInfo extends AppCompatActivity {

    SessionManager session;

    TextView mobilenum, cname, email, mobilenumopt, aadhar, address;

    SharedPreferences userid, username, phonenumber, phonenumberopt, aadharr, emailid, addresss;

    String text, checkid = "", checkname = "", checkphonenumber = "", checkphonenumberopt = "", checkaadharr = "", checkemailid = "", checkaddresss = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salesman_info_list);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        session = new SessionManager(getApplicationContext());

        userid = SalesManInfo.this.getSharedPreferences("MyPref", 0);
        username = SalesManInfo.this.getSharedPreferences("MyPref", 0);
        phonenumber = SalesManInfo.this.getSharedPreferences("MyPref", 0);
        phonenumberopt = SalesManInfo.this.getSharedPreferences("MyPref", 0);
        aadharr = SalesManInfo.this.getSharedPreferences("MyPref", 0);
        emailid = SalesManInfo.this.getSharedPreferences("MyPref", 0);
        addresss = SalesManInfo.this.getSharedPreferences("MyPref", 0);

        mobilenum = (TextView) findViewById(R.id.tv_mobile_number_value);
        email = (TextView) findViewById(R.id.tv_email_value);
        cname = (TextView) findViewById(R.id.tv_heading);
        mobilenumopt = (TextView) findViewById(R.id.tv_mobile_number_optional_value);
        aadhar = (TextView) findViewById(R.id.tv_aadhar_value);
        address = (TextView) findViewById(R.id.tv_address_value);

        checkid = userid.getString("userid", "11");
        Log.d("checkmyid", "" + checkid);

        checkname = username.getString("username", "ManiKandan");
        Log.d("checkmyname", "" + checkname);

        checkphonenumber = phonenumber.getString("phone", "0123");
        Log.d("checkmyphone", "" + checkphonenumber);

        checkphonenumberopt = phonenumberopt.getString("phoneopt", "0123");
        Log.d("checkmyphoneopt", "" + checkphonenumberopt);

        checkaadharr = aadharr.getString("aadhar", "12");
        Log.d("checkmyaadhar", "" + checkaadharr);

        checkemailid = emailid.getString("emailid", "mani@gmail.com");
        Log.d("checkmyemailid", "" + checkemailid);

        checkaddresss = addresss.getString("address", "try");
        Log.d("checkmyaddress", "" + checkaddresss);

        checkaadharr = aadharr.getString("aadhar", "123");
        Log.d("checkmyaadhar", "" + checkaadharr);

        mobilenum.setText("" + checkphonenumber);
        email.setText("" + checkemailid);
        cname.setText("" + checkname);
        mobilenumopt.setText("" + checkphonenumberopt);
        aadhar.setText("" + checkaadharr);
        address.setText("" + checkaddresss);

    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }
}