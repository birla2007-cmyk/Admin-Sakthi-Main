package com.prime.admin.sakthi.activity.qrdr;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;
import com.prime.admin.sakthi.activity.RecyclerTouchListener;
import com.prime.admin.sakthi.adapter.DialogDriverListAdapter;
import com.prime.admin.sakthi.model.DriverInfoDetails;
import com.prime.admin.sakthi.model.DriverInfoResponse;
import com.prime.admin.sakthi.rest.ApiClient;
import com.prime.admin.sakthi.rest.ApiInterface;
import com.prime.admin.sakthi.util.Utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DateActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity QR";
    String class_check = "", qr_data = "", qr_data_date = "", qr_datas = "";
    ProgressDialog progressDialog;
    String DataQr, DataDate, Data1, Data2, Datadt;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    Button date_confirm;
    EditText edittext_date, edittext_driver_name;
    ArrayList<DriverInfoDetails> items;
    DriverInfoDetails itemInfo;
    SearchView search;
    RecyclerView rv;
    DialogDriverListAdapter iadapter;


    SimpleDateFormat sdfs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker_th);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        edittext_date = (EditText) findViewById(R.id.edittext_date);
        edittext_driver_name = (EditText) findViewById(R.id.edittext_driver_name);
        date_confirm = (Button) findViewById(R.id.date_confirm);

        sdfs = new SimpleDateFormat("yyyy-MM-dd");
        Common.DateForDriverBillTaken = sdfs.format(new Date());
        edittext_date.setText(Common.DateForDriverBillTaken);

        edittext_driver_name.setText("SelectDriverName");

        if (edittext_date.getText().equals("Select Date")) {
            date_confirm.setVisibility(View.GONE);
        } else if (edittext_driver_name.getText().equals("Select Driver Name")) {
            date_confirm.setVisibility(View.GONE);
        } else {
            date_confirm.setVisibility(View.VISIBLE);
        }

        edittext_driver_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popitem();
            }
        });

        sdfs = new SimpleDateFormat("yyyy-MM-dd");

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

            private void updateLabel() {
                String myFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                edittext_date.setText(sdf.format(myCalendar.getTime()));
                Common.DateForDriverBillTaken = sdf.format(myCalendar.getTime());
            }
        };

        edittext_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(DateActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        date_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edittext_driver_name.getText().toString().equals("SelectDriverName")) {
                    Toast.makeText(getApplicationContext(), "Please Select Driver Name", Toast.LENGTH_SHORT).show();

                } else {
                    startActivity(new Intent(DateActivity.this, com.prime.admin.sakthi.activity.qrdr.DecoderActivity.class));
                    DateActivity.this.finish();
                }
            }
        });

    }

    public void popitem() {
        progressDialog = new ProgressDialog(DateActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Show Driver List"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        String baseUrl = Utils.getBaseUrl(this);
        ApiClient.getClient(baseUrl).getDriverInfo().enqueue(new DateActivity.ShowItemList());
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }

    class ShowItemList implements Callback<DriverInfoResponse> {

        ShowItemList() {

        }

        public void onResponse(Call<DriverInfoResponse> call, Response<DriverInfoResponse> response) {
            int success = ((DriverInfoResponse) response.body()).getSuccess();
            if (success == 1) {
                items = ((DriverInfoResponse) response.body()).getResults();
                Gson gson = new Gson();
                String valuesString = gson.toJson(items);
                System.out.println(valuesString);
//                session.setItems(valuesString);
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                final Dialog dialog = new Dialog(DateActivity.this);
                dialog.setContentView(R.layout.fragment_item_list);
                search = (SearchView) dialog.findViewById(R.id.search);
                rv = (RecyclerView) dialog.findViewById(R.id.card_recycler_view_item_list);
                rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                iadapter = new DialogDriverListAdapter(getApplicationContext(), items);
                rv.setAdapter(iadapter);
                dialog.show();

                Toolbar toolbar2 = (Toolbar) dialog.findViewById(R.id.toolbar4);
                toolbar2.setTitle("Driver List");

                search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String newText) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String query) {
                        Log.i("well", " this worked");
                        iadapter.getFilter().filter(query);
                        return false;
                    }
                });

                rv.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rv, new RecyclerTouchListener.ClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        itemInfo = items.get(position);

                        Common.DriverIDForBllTaken = String.valueOf(itemInfo.getDriver_id());
                        Log.d("Driver", "" + Common.DriverIDForBllTaken);

                        Common.DriverNameForBllTaken = itemInfo.getDriver_name();
                        Log.d("Driver", "" + Common.DriverNameForBllTaken);

                        dialog.dismiss();

                        if (Common.DriverIDForBllTaken == null && Common.DriverNameForBllTaken == null) {
                            edittext_driver_name.setText("Select Driver Name");
                        } else if (Common.DriverIDForBllTaken.isEmpty() && Common.DriverNameForBllTaken.isEmpty()) {
                            edittext_driver_name.setText("Select Driver Name");
                        } else {
                            edittext_driver_name.setText("" + Common.DriverNameForBllTaken);
                        }
                    }

                    @Override
                    public void onLongClick(View view, int position) {

                    }
                }));

                Log.d("jjj", "Number of items received: " + items.size());
            } else if (success == 0) {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                String message = response.body().getMessage();

                new SweetAlertDialog(DateActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.cancel();
                            }
                        })
                        .show();
            } else if (success == 2) {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                String message = response.body().getMessage();

                new SweetAlertDialog(DateActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.cancel();
                            }
                        })

                        .show();
            } else {
                progressDialog.setCancelable(false);
                progressDialog.dismiss();

                new SweetAlertDialog(DateActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("No Record Found")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.cancel();
                            }
                        })
                        .show();
            }
        }

        public void onFailure(Call<DriverInfoResponse> call, Throwable t) {

        }
    }

}
