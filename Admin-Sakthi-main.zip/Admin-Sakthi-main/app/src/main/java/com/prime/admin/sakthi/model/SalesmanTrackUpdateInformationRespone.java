package com.prime.admin.sakthi.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Admin on 11/24/2016.
 */

public class SalesmanTrackUpdateInformationRespone {

    @SerializedName("success")
    private int success;
    @SerializedName("message")
    private String message;

    public int getSuccess() {
        return this.success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
