package com.prime.admin.sakthi.activity;

import android.Manifest;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.material.navigation.NavigationView;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.SQLiteQrCompanyScan.QrCompanyList;
import com.prime.admin.sakthi.activity.SQLiteQrDirectDeliveredScan.QrDirectDeliveredScanList;
import com.prime.admin.sakthi.activity.SQLiteQrLsDeliveredScan.QrLsDeliveredScanList;
import com.prime.admin.sakthi.location.LocationHelper;
import com.prime.admin.sakthi.util.SessionManager;
import com.prime.admin.sakthi.views.ItemCardView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, LocationHelper.OnLocationCompleteListener {
    private static final String TAG = "UserActivity";
    final private int REQUEST_CODE_ASK_PERMISSIONS = 123;
    TextView text_user;
    SessionManager session;
    ItemCardView ll_salesman_scan, ll_company_scan, ll_driver_scan, ll_direct_delivered_scan, ll_company_withoutimg_scan, ll_lorry_shed_delivered_scan, ll_direct_return_scan, ll_lorry_shed_return_scan;
    SharedPreferences userid, username, phonenumber, phonenumberopt, aadharr, emailid, addresss, type;
    String longitude = "", address_save = "", latitude = "", checkid = "", checkname = "", dayOfTheWeek = "";
    boolean doubleBackToExitPressedOnce = false;
    private LocationHelper locationHelper;
    private Geocoder geocoder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
        this.overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
        getLocationPermission();

        userid = MainActivity.this.getSharedPreferences("MyPref", 0);
        username = MainActivity.this.getSharedPreferences("MyPref", 0);
        phonenumber = MainActivity.this.getSharedPreferences("MyPref", 0);
        phonenumberopt = MainActivity.this.getSharedPreferences("MyPref", 0);
        aadharr = MainActivity.this.getSharedPreferences("MyPref", 0);
        emailid = MainActivity.this.getSharedPreferences("MyPref", 0);
        addresss = MainActivity.this.getSharedPreferences("MyPref", 0);
        type = MainActivity.this.getSharedPreferences("MyPref", 0);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        session = new SessionManager(getApplicationContext());
        checkid = userid.getString("userid", "11");
        Log.d("checkmyid", "" + checkid);

        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date d = new Date();
        dayOfTheWeek = sdf.format(d);
        Log.d("dayOfTheWeek", "" + dayOfTheWeek);

        checkname = username.getString("username", "ManiKandan");
        Log.d("checkmyname", "" + checkname);

        String TypesUser = type.getString("type", "ManiKandan");

        ll_salesman_scan = (ItemCardView) findViewById(R.id.ll_salesman_scan);
        ll_company_scan = (ItemCardView) findViewById(R.id.ll_company_scan);
        ll_driver_scan = (ItemCardView) findViewById(R.id.ll_driver_scan);
        ll_direct_delivered_scan = (ItemCardView) findViewById(R.id.ll_direct_delivered_scan);
        ll_lorry_shed_delivered_scan = (ItemCardView) findViewById(R.id.ll_lorry_shed_delivered_scan);
        ll_direct_return_scan = (ItemCardView) findViewById(R.id.ll_direct_return_scan);
        ll_lorry_shed_return_scan = (ItemCardView) findViewById(R.id.ll_lorry_shed_return_scan);
        ll_company_withoutimg_scan = (ItemCardView) findViewById(R.id.ll_company_withoutimg_scan);

        if (TypesUser.equals("salesman")) {
            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setContentText("Warning !").setContentText("You Are Not Authorised User").setConfirmText("Ok").setConfirmClickListener(sDialog -> {
                MainActivity.this.finish();
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                sDialog.cancel();
            }).show();
        } else if (TypesUser.equals("driver")) {
            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setContentText("Warning !").setContentText("You Are Not Authorised User").setConfirmText("Ok").setConfirmClickListener(sDialog -> {
                MainActivity.this.finish();
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                sDialog.cancel();
            }).show();
        } else {

            ll_salesman_scan.setOnClickListener(v -> {
                Common.DateForSalesman = "";

                if (Common.DateForSalesman == null) {
                    Intent i1 = new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qr.DateActivity.class);
                    startActivity(i1);
                } else if (Common.DateForSalesman.isEmpty()) {
                    Intent i1 = new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qr.DateActivity.class);
                    startActivity(i1);
                } else {
                    Intent i1 = new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qr.DecoderActivity.class);
                    startActivity(i1);
                }

            });

            ll_driver_scan.setOnClickListener(v -> {
                Common.DriverNameForBllTaken = "";
                Common.DriverIDForBllTaken = "";
                Common.DateForDriverBillTaken = "";

                if (Common.DriverNameForBllTaken == null && Common.DriverIDForBllTaken == null) {
                    Intent i1 = new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrdr.DateActivity.class);
                    startActivity(i1);
                } else if (Common.DriverNameForBllTaken.isEmpty() && Common.DriverIDForBllTaken.isEmpty()) {
                    Intent i1 = new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrdr.DateActivity.class);
                    startActivity(i1);
                } else {
                    Intent i1 = new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrdr.DecoderActivity.class);
                    startActivity(i1);
                }

            });

            ll_direct_delivered_scan.setOnClickListener(v -> {
                Common.DeliveredBillCLoseDate = "";

                if (Common.DeliveredBillCLoseDate == null) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrdirectdeliveredbillclose.DateActivity.class));
                } else if (Common.DeliveredBillCLoseDate.isEmpty()) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrdirectdeliveredbillclose.DateActivity.class));
                } else {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrdirectdeliveredbillclose.DecoderActivity.class));
                }

            });

            ll_lorry_shed_delivered_scan.setOnClickListener(v -> {
                Common.DeliveredBillCLoseDate = "";

                if (Common.DeliveredBillCLoseDate == null) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrlorrysheddeliveredbillclose.DateActivity.class));
                } else if (Common.DeliveredBillCLoseDate.isEmpty()) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrlorrysheddeliveredbillclose.DateActivity.class));
                } else {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrlorrysheddeliveredbillclose.DecoderActivity.class));
                }
            });

            ll_direct_return_scan.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrdirectreturnbillclose.DecoderActivity.class)));

            ll_lorry_shed_return_scan.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrlorryshedreturnbillclose.DecoderActivity.class)));

            ll_company_withoutimg_scan.setOnClickListener(v -> {
                Common.DateForCompanyWithhoutImg = "";

                if (Common.DateForCompanyWithhoutImg == null) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrcompanyscanwithoutimg.DateActivity.class));
                } else if (Common.DateForCompanyWithhoutImg.isEmpty()) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrcompanyscanwithoutimg.DateActivity.class));
                } else {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrcompanyscanwithoutimg.DecoderActivity.class));
                }
            });

            ll_company_scan.setOnClickListener(v -> {

                Common.DateForCompany = "";

                if (Common.DateForCompany == null) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrcompanyscanwithimg.DateActivity.class));
                } else if (Common.DateForCompany.isEmpty()) {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrcompanyscanwithimg.DateActivity.class));
                } else {
                    startActivity(new Intent(MainActivity.this, com.prime.admin.sakthi.activity.qrcompanyscanwithimg.DecoderActivity.class));
                }

            });

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.setDrawerListener(toggle);
            toggle.syncState();

            NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(this);
            View v = navigationView.getHeaderView(0);
            text_user = (TextView) v.findViewById(R.id.txt_user);
            text_user.setText(checkname);
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Are you sure you want to Exit").setCancelText("No").setConfirmText("Yes").showCancelButton(true).setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sDialog) {
                Log.d("SweetAlertDialog", "1");

                sDialog.cancel();
            }
        }).setConfirmClickListener(sDialog -> {
            Log.d("SweetAlertDialog", "2");

            new Handler().postDelayed(() -> doubleBackToExitPressedOnce = true, 2000);

            android.os.Process.killProcess(android.os.Process.myPid());

            finish();

            overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);

            sDialog.cancel();
        }).show();
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_about) {

        } else if (id == R.id.nav_qrddsl) {
            if (latitude.equalsIgnoreCase("") && longitude.equalsIgnoreCase("")) {
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Location").setContentText("Please Check Location Is On / Location Not Found!.. Try Again..").setConfirmText("Ok").show();
            } else {
                startActivity(new Intent(MainActivity.this, QrDirectDeliveredScanList.class));
            }
        } else if (id == R.id.nav_qrlsdsl) {
            if (latitude.equalsIgnoreCase("") && longitude.equalsIgnoreCase("")) {
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Location").setContentText("Please Check Location Is On / Location Not Found!.. Try Again..").setConfirmText("Ok").show();
            } else {
                startActivity(new Intent(MainActivity.this, QrLsDeliveredScanList.class));
            }
        } else if (id == R.id.nav_qrcsl) {
            if (latitude.equalsIgnoreCase("") && longitude.equalsIgnoreCase("")) {
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Location").setContentText("Please Check Location Is On / Location Not Found!.. Try Again..").setConfirmText("Ok").show();
            } else {
                startActivity(new Intent(MainActivity.this, QrCompanyList.class));
            }
        } else if (id == R.id.nav_myinfo) {
            if (latitude.equalsIgnoreCase("") && longitude.equalsIgnoreCase("")) {
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Location").setContentText("Please Check Location Is On / Location Not Found!.. Try Again..").setConfirmText("Ok").show();
            } else {
                startActivity(new Intent(MainActivity.this, SalesManInfo.class));
            }

        } else if (id == R.id.nav_above) {
            if (latitude.equalsIgnoreCase("") && longitude.equalsIgnoreCase("")) {
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("Location").setContentText("Please Check Location Is On / Location Not Found!.. Try Again..").setConfirmText("Ok").show();
            } else {
                startActivity(new Intent(MainActivity.this, AboutUs.class));
            }

        } else if (id == R.id.nav_logout) {
            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE).setTitleText("You want to Logout").setCancelText("No").setConfirmText("Yes").showCancelButton(true).setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sDialog) {
                    Log.d("SweetAlertDialog", "1");

                    sDialog.cancel();
                }
            }).setConfirmClickListener(sDialog -> {

                Intent i1 = new Intent(MainActivity.this, LoginActivity.class);
                i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i1);
                MainActivity.this.finish();
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);

                sDialog.cancel();
            }).show();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void getLocationPermission() {

        int hasGetLocationPermission = ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (hasGetLocationPermission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            locationHelper = new LocationHelper(MainActivity.this, this);
        }
    }

    @Override
    public void getLocationUpdate(Location location) {
        try {
            Log.d(TAG, "getLatitude : " + location.getLatitude());
            Log.d(TAG, "getLatitude : " + location.getLongitude());
            latitude = "" + location.getLatitude();
            longitude = "" + location.getLongitude();

            Common.GetLangitude = String.valueOf(location.getLongitude());
            Common.GetLatitude = String.valueOf(location.getLatitude());

            List<Address> addressList = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if (addressList != null && addressList.size() > 0) {
                Address address = addressList.get(0);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                    sb.append(address.getAddressLine(i)).append("\n");
                    address_save = address.getAddressLine(i);
                }

                address_save = addressList.get(0).getAddressLine(0);
                Log.d(TAG, "getaddresses3 : " + address_save);

                Common.GetAddress = addressList.get(0).getAddressLine(0);

                Log.d("addressList", "" + Common.GetAddress);
                Log.d("addressList", "" + Common.GetLangitude);
                Log.d("addressList", "" + Common.GetLatitude);
            }

        } catch (IOException e) {
            Log.d(TAG, "getLocationUpdate exception : " + e);
        }

    }

    @Override
    public void onError(ConnectionResult connectionResult, Status status, String error) {
        if (connectionResult != null) {
            if (connectionResult.hasResolution()) {
                try {
                    connectionResult.startResolutionForResult(MainActivity.this, LocationHelper.CONNECTION_FAILURE_RESOLUTION_REQUEST);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }
            }
        } else if (status != null) {
            try {
                status.startResolutionForResult(MainActivity.this, LocationHelper.REQUEST_CHECK_SETTINGS);
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode != REQUEST_CODE_ASK_PERMISSIONS) {

            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        } else {

            if (grantResults.length != 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locationHelper = new LocationHelper(MainActivity.this, this);
            } else {

                int hasGetLocationPermission = ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION);
                if (hasGetLocationPermission != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE_ASK_PERMISSIONS);
                }
            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "" + requestCode + "\t" + resultCode + "\t" + data);
        locationHelper.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "Ondestroy");
        super.onDestroy();
        if (locationHelper != null) locationHelper.stopLocationUpdates();
    }
}