package com.prime.admin.sakthi.activity.qrdirectdeliveredbillclose;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.dlazaro66.qrcodereaderview.QRCodeReaderView;
import com.dlazaro66.qrcodereaderview.QRCodeReaderView.OnQRCodeReadListener;
import com.google.android.material.snackbar.Snackbar;
import com.prime.admin.sakthi.R;
import com.prime.admin.sakthi.activity.Common;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DecoderActivity extends AppCompatActivity
        implements ActivityCompat.OnRequestPermissionsResultCallback, OnQRCodeReadListener {

    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;
    private static final int MY_PERMISSION_REQUEST_CAMERA = 0;
    private static final int CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100;
    private static final int CAMERA_CAPTURE_VIDEO_REQUEST_CODE = 200;
    private static final String IMAGE_DIRECTORY_NAME = "Krishnamills Camera Cache Org";
    private static final String IMAGE_DIRECTORY_NAME_ORG = "Direct Delivered Bills";
    ProgressDialog progressDialog;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    SimpleDateFormat sdfs;
    private ViewGroup mainLayout;
    private File actualImage;
    private File compressedImage;
    private Uri fileUri; // file url to store image/video
    private TextView resultTextView;
    private QRCodeReaderView qrCodeReaderView;
    private CheckBox flashlightCheckBox;
    private CheckBox enableDecodingCheckBox;
    private PointsOverlayView pointsOverlayView;
    private String absolutePhotoPath = "";
    private final ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {
            fileUri = getOutputMediaFileUri(1);
            launchUploadActivity(true);
        }
//                else {
//                    dispatchTakePictureIntent();
//                }
    });
    private boolean isCameraOpen = false;

    private static File getOutputMediaFile(int type) {
//        File mediaStorageDir = new File(
//                Environment
//                        .getExternalStorageDirectory(),
//                IMAGE_DIRECTORY_NAME);
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), IMAGE_DIRECTORY_NAME);

        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("Manikandan", "Oops! Failed create "
                        + IMAGE_DIRECTORY_NAME + " directory");
                return null;
            }
        }
        File mediaStorageDirOrg = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), IMAGE_DIRECTORY_NAME_ORG);
//        File mediaStorageDirOrg = new File(
//                Environment
//                        .getExternalStorageDirectory(),
//                IMAGE_DIRECTORY_NAME_ORG);

        if (!mediaStorageDirOrg.exists()) {
            if (!mediaStorageDirOrg.mkdirs()) {
                Log.d("Manikandan", "Oops! Failed create "
                        + IMAGE_DIRECTORY_NAME_ORG + " directory");
                return null;
            }
        }

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator
                    + "IMG_" + timeStamp + ".jpg");
        } else if (type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator
                    + "VID_" + timeStamp + ".mp4");
        } else {
            return null;
        }

        return mediaFile;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_decoder);

        mainLayout = (ViewGroup) findViewById(R.id.main_layout);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.overridePendingTransition(R.anim.anim_slide_in_left,
                R.anim.anim_slide_out_left);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            initQRCodeReaderView();
        } else {
            requestCameraPermission();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (qrCodeReaderView != null) {
            qrCodeReaderView.startCamera();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (qrCodeReaderView != null) {
            qrCodeReaderView.stopCamera();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != MY_PERMISSION_REQUEST_CAMERA) {
            return;
        }

        if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Snackbar.make(mainLayout, "Camera permission was granted.", Snackbar.LENGTH_SHORT).show();
            initQRCodeReaderView();
        } else {
            Snackbar.make(mainLayout, "Camera permission request was denied.", Snackbar.LENGTH_SHORT)
                    .show();
        }
    }

    @Override
    public void onQRCodeRead(String text, PointF[] points) {

        Common.QrData = text;

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        if (!isCameraOpen) {
            isCameraOpen = true;
            dispatchTakePictureIntent();
        }
//        captureImage();

        pointsOverlayView.setPoints(points);

        if (!isDeviceSupportCamera()) {
            Toast.makeText(getApplicationContext(),
                    "Sorry! Your device doesn't support camera",
                    Toast.LENGTH_LONG).show();
            finish();
        }

    }

    private boolean isDeviceSupportCamera() {
        return getApplicationContext().getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_CAMERA_ANY);
    }

    private void dispatchTakePictureIntent() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
            }

            fileUri = FileProvider.getUriForFile(this, getPackageName() + ".provider", photoFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
            cameraLauncher.launch(takePictureIntent);
        }
    }

    public File createImageFile() throws IOException {
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        String timeStamp = Long.toString(System.currentTimeMillis());

        File image = File.createTempFile("IMG_" + timeStamp + "_", ".jpg", storageDir);
        setAbsolutePhotoPath(image.getAbsolutePath());

        return image;
    }

    private String getAbsolutePhotoPath() {
        return absolutePhotoPath;
    }

    private void setAbsolutePhotoPath(String absolutePhotoPath) {
        this.absolutePhotoPath = absolutePhotoPath;
    }

    private void captureImage() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("file_uri", fileUri);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        fileUri = savedInstanceState.getParcelable("file_uri");
    }

    private void launchUploadActivity(boolean isImage) {

        Common.ImageForDirectDeliveredScan = fileUri.getPath();
        Common.ImageForDirectDeliveredScanII = isImage;

        actualImage = new File(fileUri.getPath());

        progressDialog = new ProgressDialog(DecoderActivity.this);
        progressDialog.setMessage("Loading..."); // Setting Message
        progressDialog.setTitle("Checking Image"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog

        Log.d("Compressor", "Compressed image save in " + actualImage);
        Log.d("Compressor", "Compressed image save in " + Common.ImageForDirectDeliveredScan);

        if (actualImage == null) {
            showError("Please choose an image!");
        } else {

            // Compress image in main thread
            //compressedImage = new Compressor(this).compressToFile(actualImage);
            //setCompressedImage();

            // Compress image to bitmap in main thread
            //compressedImageView.setImageBitmap(new Compressor(this).compressToBitmap(actualImage));

            compressAndSaveImage();

            // Compress image using RxJava in background thread
//            new Compressor(this)
//                    .compressToFileAsFlowable(actualImage)
//                    .subscribeOn(Schedulers.io())
//                    .observeOn(AndroidSchedulers.mainThread())
//                    .subscribe(file -> {
//                        compressedImage = file;
//                        setCompressedImage();
//                    }, throwable -> {
//                        throwable.printStackTrace();
//                        showError(throwable.getMessage());
//                    });

        }
    }

    private void setCompressedImage() {
//    compressedImageView.setImageBitmap(BitmapFactory.decodeFile(compressedImage.getAbsolutePath()));
//    compressedSizeTextView.setText(String.format("Size : %s", getReadableFileSize(compressedImage.length())));

        Common.ImageForDirectDeliveredScanOrg = compressedImage.getPath();

        progressDialog.setCancelable(false);
        progressDialog.dismiss();

        Intent i1 = new Intent(DecoderActivity.this, MainActivity.class);
        i1.putExtra("qr", "1");
        i1.putExtra("qr_data", Common.QrData);
        startActivity(i1);
        DecoderActivity.this.finish();

        //Toast.makeText(this, "Compressed image save in " + compressedImage.getPath(), Toast.LENGTH_LONG).show();
        Log.d("Compressor", "Compressed image save in " + compressedImage.getPath());
    }

    public void showError(String errorMessage) {
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
    }

    public String getReadableFileSize(long size) {
        if (size <= 0) {
            return "0";
        }
        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    private void requestRuntimePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == CAMERA_CAPTURE_IMAGE_REQUEST_CODE) {
//            if (resultCode == RESULT_OK) {
//                launchUploadActivity(true);
//            } else if (resultCode == RESULT_CANCELED) {
//                Toast.makeText(getApplicationContext(),
//                                "User cancelled image capture", Toast.LENGTH_SHORT)
//                        .show();
//            } else {
//                Toast.makeText(getApplicationContext(),
//                                "Sorry! Failed to capture image", Toast.LENGTH_SHORT)
//                        .show();
//            }
//        } else
        if (requestCode == CAMERA_CAPTURE_VIDEO_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {

            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(getApplicationContext(),
                                "User cancelled video recording", Toast.LENGTH_SHORT)
                        .show();
            } else {
                Toast.makeText(getApplicationContext(),
                                "Sorry! Failed to record video", Toast.LENGTH_SHORT)
                        .show();
            }
        }
    }

    public Uri getOutputMediaFileUri(int type) {
        return Uri.fromFile(getOutputMediaFile(type));
    }

    public void compressAndSaveImage() {
        // Load the original image from a file or resource (for demonstration, we load from resources)
        Bitmap originalBitmap = BitmapFactory.decodeFile(getAbsolutePhotoPath());

        if (originalBitmap == null) {
            Toast.makeText(this, "Failed to load the original image.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Compress the image
        int quality = 50; // Adjust the quality (0-100) as needed
        Bitmap compressedBitmap = compressBitmap(originalBitmap, quality);

        // Save the compressed image to the Downloads folder
        if (saveBitmapToDownloads(compressedBitmap)) {
            Toast.makeText(this, "Image saved in Downloads folder.", Toast.LENGTH_SHORT).show();
            setCompressedImage();
        } else {
            Toast.makeText(this, "Failed to save the image.", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap compressBitmap(Bitmap bitmap, int quality) {
        // Create a new ByteArrayOutputStream to compress the image
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream);
        byte[] byteArray = stream.toByteArray();

        // Decode the compressed byte array back into a Bitmap
        return BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
    }

    private boolean saveBitmapToDownloads(Bitmap bitmap) {
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File file = new File(downloadsDir + "/" + IMAGE_DIRECTORY_NAME + "/", "IMG" + timeStamp + ".jpg");
        compressedImage = file;

        try {
            FileOutputStream outputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream); // 100% quality
            outputStream.close();
            compressedImage = file;
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void requestCameraPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
            Snackbar.make(mainLayout, "Camera access is required to display the camera preview.",
                    Snackbar.LENGTH_INDEFINITE).setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityCompat.requestPermissions(DecoderActivity.this, new String[]{
                            Manifest.permission.CAMERA
                    }, MY_PERMISSION_REQUEST_CAMERA);
                }
            }).show();
        } else {
            Snackbar.make(mainLayout, "Permission is not available. Requesting camera permission.",
                    Snackbar.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.CAMERA
            }, MY_PERMISSION_REQUEST_CAMERA);
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right,
                R.anim.anim_slide_out_right);

    }

    private void initQRCodeReaderView() {
        View content = getLayoutInflater().inflate(R.layout.content_decoderdlsdbc, mainLayout, true);

        qrCodeReaderView = (QRCodeReaderView) content.findViewById(R.id.qrdecoderview);
        resultTextView = (TextView) content.findViewById(R.id.result_text_view);
        flashlightCheckBox = (CheckBox) content.findViewById(R.id.flashlight_checkbox);
        enableDecodingCheckBox = (CheckBox) content.findViewById(R.id.enable_decoding_checkbox);
        pointsOverlayView = (PointsOverlayView) content.findViewById(R.id.points_overlay_view);

        requestRuntimePermission();

        if (Common.DeliveredBillCLoseDate == null) {

            sdfs = new SimpleDateFormat("yyyy-MM-dd");
            Common.DeliveredBillCLoseDate = sdfs.format(new Date());
            resultTextView.setText(Common.DeliveredBillCLoseDate);

        } else if (Common.DeliveredBillCLoseDate.isEmpty()) {

            sdfs = new SimpleDateFormat("yyyy-MM-dd");
            Common.DeliveredBillCLoseDate = sdfs.format(new Date());
            resultTextView.setText(Common.DeliveredBillCLoseDate);

        } else {
            resultTextView.setText("" + Common.DeliveredBillCLoseDate);
        }

        sdfs = new SimpleDateFormat("yyyy-MM-dd");

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

            private void updateLabel() {
                String myFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                resultTextView.setText(sdf.format(myCalendar.getTime()));
                Common.DeliveredBillCLoseDate = sdf.format(myCalendar.getTime());
            }
        };

        resultTextView.setOnClickListener(view -> new DatePickerDialog(DecoderActivity.this, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show());

        enableDecodingCheckBox.setVisibility(View.GONE);

        qrCodeReaderView.setAutofocusInterval(2000L);
        qrCodeReaderView.setOnQRCodeReadListener(this);
        qrCodeReaderView.setBackCamera();
        flashlightCheckBox.setOnCheckedChangeListener((compoundButton, isChecked) -> qrCodeReaderView.setTorchEnabled(isChecked));
        enableDecodingCheckBox.setOnCheckedChangeListener((compoundButton, isChecked) -> qrCodeReaderView.setQRDecodingEnabled(isChecked));
        qrCodeReaderView.startCamera();
    }
}