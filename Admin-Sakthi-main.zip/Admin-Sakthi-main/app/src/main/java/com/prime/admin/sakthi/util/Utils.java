package com.prime.admin.sakthi.util;

import static com.prime.admin.sakthi.util.SessionManager.PREF_NAME;
import static com.prime.admin.sakthi.util.SessionManager.baseUrl;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.prime.admin.sakthi.R;


public class Utils {
    public static void makeNotification(
            int notificationID,
            String message,
            Context context,
            String title,
            Class<?> targetActivity
    ) {
        // Make a channel if necessary
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create the NotificationChannel, but only on API 26+ because
            // the NotificationChannel class is new and not in the support library
            String name = "SalesMan Informative Channel";
            String description = "This tells about Login, Sales Order Edit Order and Receipt generation";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("CHANNEL_ID", name, importance);
            channel.setDescription(description);

            // Add the channel
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
        Intent intent = new Intent(context, targetActivity);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addNextIntentWithParentStack(intent);
        int iUniqueId = (int) (System.currentTimeMillis() & 0xfffffff);
        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(
                iUniqueId,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Create the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "CHANNEL_ID")
                .setSmallIcon(R.drawable.primesaleslogo)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(resultPendingIntent) // Set the intent to open the target activity
                .setAutoCancel(true); // Automatically remove the notification when clicked

        // Show the notification
        NotificationManagerCompat.from(context).notify(notificationID, builder.build());
    }

    public static void setBaseUrl(Context context, String url) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(baseUrl, url);
        editor.apply();
    }

    public static String getBaseUrl(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getString(baseUrl, "https://bsakthicrop.in/");
    }
}
